# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: t17-registry.e2e.ts >> screen registry certification >> all 27 routes resolve and independently satisfy their registered screen contract
- Location: tests/e2e/t17-ui/t17-registry.e2e.ts:56:3

# Error details

```
Error: Channel closed
```

```
Error: page.goto: Test ended.
Call log:
  - navigating to "http://localhost:5173/me/preferences", waiting until "load"

```

# Test source

```ts
  45  |   page: import('@playwright/test').Page,
  46  |   contract: (typeof SCREEN_REGISTRY)[number]['contract'],
  47  | ) {
  48  |   if (contract.heading) {
  49  |     await expect(page.getByRole('heading', { name: contract.heading }).first()).toBeVisible();
  50  |   }
  51  |   if (contract.text) await expect(page.getByText(contract.text).first()).toBeVisible();
  52  |   if (contract.testId) await expect(page.getByTestId(contract.testId)).toBeVisible();
  53  | }
  54  | 
  55  | test.describe('screen registry certification', () => {
  56  |   test('all 27 routes resolve and independently satisfy their registered screen contract', async ({
  57  |     page,
  58  |   }, info) => {
  59  |     test.setTimeout(240_000);
  60  |     const results: Array<{
  61  |       id: string;
  62  |       name: string;
  63  |       path: string;
  64  |       routeExists: boolean;
  65  |       screenContractSatisfied: boolean;
  66  |     }> = [];
  67  | 
  68  |     // Public surfaces without any session.
  69  |     await page.goto('/landing');
  70  |     await page.context().clearCookies();
  71  |     await page.evaluate(() => {
  72  |       localStorage.clear();
  73  |       sessionStorage.clear();
  74  |     });
  75  |     for (const screen of SCREEN_REGISTRY.filter((s) => s.auth === 'public')) {
  76  |       await page.goto(screen.path);
  77  |       await expect(page).toHaveURL(
  78  |         new RegExp(`${screen.path.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}$`),
  79  |       );
  80  |       await assertScreenContract(page, screen.contract);
  81  |       await expect(nav(page)).toHaveCount(0);
  82  |       await layout(page);
  83  |       results.push({
  84  |         id: screen.id,
  85  |         name: screen.name,
  86  |         path: screen.path,
  87  |         routeExists: true,
  88  |         screenContractSatisfied: true,
  89  |       });
  90  |     }
  91  |     // Screen 03 without context is the honest empty state, never an OTP form.
  92  |     await page.goto('/auth/verify');
  93  |     await expect(page.getByTestId('verify-context-missing')).toBeVisible();
  94  |     await expect(page.locator('input[inputmode="numeric"]')).toHaveCount(0);
  95  | 
  96  |     // Session surfaces on real seeded truth.
  97  |     await reset(page);
  98  |     for (const screen of SCREEN_REGISTRY.filter((s) => s.id >= '04' && s.id <= '06')) {
  99  |       await page.goto(screen.path);
  100 |       await expect(page).toHaveURL(new RegExp(`${screen.path}$`));
  101 |       await assertScreenContract(page, screen.contract);
  102 |       await expect(page.getByRole('progressbar')).toHaveAttribute(
  103 |         'aria-valuenow',
  104 |         String(Number(screen.id) - 3),
  105 |       );
  106 |       await expect(nav(page)).toHaveCount(0);
  107 |       await layout(page);
  108 |       results.push({
  109 |         id: screen.id,
  110 |         name: screen.name,
  111 |         path: screen.path,
  112 |         routeExists: true,
  113 |         screenContractSatisfied: true,
  114 |       });
  115 |     }
  116 |     await completeOnboarding(page);
  117 |     // Seeded T13 review evidence gives screen 09 a real pending scan.
  118 |     await control(page, 't13-scans');
  119 |     const planId = await generatePlan(page);
  120 |     // Seeded inventory lot (planner-preview-fixtures) for screen 11.
  121 |     const lot = 'preview-stock-egg';
  122 | 
  123 |     const params: Record<string, string> = {
  124 |       ':id': 't13b-preview-fridge',
  125 |       // Real catalog slug (recipe authority snapshot); the preview DB rows are not
  126 |       // part of the catalog, so `preview-chicken` would render the 404 state.
  127 |       ':slug': 'canh-chua-ca-loc-nam-bo',
  128 |       ':planId': planId,
  129 |       ':slotId': '',
  130 |     };
  131 |     for (const screen of SCREEN_REGISTRY.filter(
  132 |       (s) => s.auth === 'session' && !(s.id >= '04' && s.id <= '06'),
  133 |     )) {
  134 |       let path = screen.path;
  135 |       if (screen.id === '11') path = `/fridge/${lot}`;
  136 |       else if (screen.id === '17') {
  137 |         // Slot ids come from the generated plan: follow the real link.
  138 |         await page.goto(`/planner/${planId}`);
  139 |         const meal = page.locator('a[href*="/meal/"]').first();
  140 |         await expect(meal).toBeVisible();
  141 |         path = (await meal.getAttribute('href'))!;
  142 |       } else {
  143 |         for (const [key, value] of Object.entries(params)) path = path.replace(key, value);
  144 |       }
> 145 |       await page.goto(path);
      |                  ^ Error: page.goto: Test ended.
  146 |       await expect(page).toHaveURL(new RegExp(`${path.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}$`));
  147 |       await assertScreenContract(page, screen.contract);
  148 |       if (screen.nav === 'visible') {
  149 |         await expect(nav(page)).toHaveCount(1);
  150 |         await expect(nav(page)).toBeVisible();
  151 |       } else {
  152 |         await expect(nav(page)).toHaveCount(0);
  153 |       }
  154 |       await settle(page);
  155 |       await layout(page);
  156 |       results.push({
  157 |         id: screen.id,
  158 |         name: screen.name,
  159 |         path,
  160 |         routeExists: true,
  161 |         screenContractSatisfied: true,
  162 |       });
  163 |     }
  164 | 
  165 |     expect(results).toHaveLength(27);
  166 |     expect(new Set(results.map((r) => r.id)).size).toBe(27);
  167 |     await info.attach('screen-registry-results', {
  168 |       body: JSON.stringify(results, null, 2),
  169 |       contentType: 'application/json',
  170 |     });
  171 |   });
  172 | 
  173 |   test('onboarding URLs own screens 04-06 across direct load, refresh and browser history', async ({
  174 |     page,
  175 |   }) => {
  176 |     await reset(page);
  177 | 
  178 |     await page.goto('/onboarding/household');
  179 |     await expect(
  180 |       page.getByRole('heading', { name: /Nhà mình thường có bao nhiêu người ăn/ }),
  181 |     ).toBeVisible();
  182 |     await expect(page.getByRole('progressbar')).toHaveAttribute('aria-valuenow', '1');
  183 |     const household = page.locator('input[type="radio"][name="household-size"]');
  184 |     await expect(household).toHaveCount(5);
  185 |     await expect(page.locator('input[type="radio"][name="household-size"]:checked')).toHaveCount(1);
  186 |     await expect(page.locator('input[name="favorite-cuisines"]')).toHaveCount(0);
  187 |     await page.locator('label:has(input[name="household-size"][value="4"])').click();
  188 |     await expect(page.locator('input[name="household-size"][value="4"]')).toBeChecked();
  189 |     await page.reload();
  190 |     await expect(page).toHaveURL(/\/onboarding\/household$/);
  191 |     await expect(page.getByRole('progressbar')).toHaveAttribute('aria-valuenow', '1');
  192 | 
  193 |     await page.getByRole('button', { name: 'Tiếp tục' }).click();
  194 |     await expect(page).toHaveURL(/\/onboarding\/preferences$/);
  195 |     await expect(page.getByRole('progressbar')).toHaveAttribute('aria-valuenow', '2');
  196 |     await page.reload();
  197 |     await expect(page).toHaveURL(/\/onboarding\/preferences$/);
  198 |     await expect(page.getByRole('progressbar')).toHaveAttribute('aria-valuenow', '2');
  199 |     const cuisines = page.locator('input[type="checkbox"][name="favorite-cuisines"]');
  200 |     const restrictions = page.locator('input[type="checkbox"][name="dietary-restrictions"]');
  201 |     await expect(cuisines).toHaveCount(7);
  202 |     expect(await cuisines.evaluateAll((items) => items.map((item) => (item as HTMLInputElement).value)))
  203 |       .toEqual(['vietnamese', 'korean', 'japanese', 'western', 'chinese', 'thai', 'other']);
  204 |     await expect(restrictions).toHaveCount(9);
  205 |     await expect(page.locator('input[name="favorite-cuisines"][value="vietnamese"]')).toBeChecked();
  206 |     await page.getByText('Hàn Quốc', { exact: true }).click();
  207 |     await page.getByText('Thịt bò', { exact: true }).click();
  208 |     await expect(page.locator('input[name="favorite-cuisines"][value="korean"]')).toBeChecked();
  209 |     await expect(page.locator('input[name="dietary-restrictions"][value="beef"]')).toBeChecked();
  210 | 
  211 |     await page.getByRole('button', { name: 'Tiếp tục' }).click();
  212 |     await expect(page).toHaveURL(/\/onboarding\/goals$/);
  213 |     await expect(page.getByRole('progressbar')).toHaveAttribute('aria-valuenow', '3');
  214 |     await expect(page.getByTestId('onboarding-preference-review')).toContainText('Hàn Quốc');
  215 |     await expect(page.getByTestId('onboarding-preference-review')).toContainText('Thịt bò');
  216 |     const goals = page.locator('input[type="radio"][name="primary-goal"]');
  217 |     await expect(goals).toHaveCount(3);
  218 |     expect(await goals.evaluateAll((items) => items.map((item) => (item as HTMLInputElement).value)))
  219 |       .toEqual(['today', 'week', 'both']);
  220 |     await expect(page.locator('input[name="primary-goal"][value="both"]')).toBeChecked();
  221 |     await page.locator('label:has(input[name="primary-goal"][value="today"])').click();
  222 |     await expect(page.locator('input[name="primary-goal"][value="today"]')).toBeChecked();
  223 | 
  224 |     await page.goBack();
  225 |     await expect(page).toHaveURL(/\/onboarding\/preferences$/);
  226 |     await expect(page.getByRole('heading', { name: /Nhà mình thích món gì/ })).toBeVisible();
  227 |     await page.goForward();
  228 |     await expect(page).toHaveURL(/\/onboarding\/goals$/);
  229 |     await expect(page.getByTestId('onboarding-preference-review')).toBeVisible();
  230 |     await expect(page.locator('input[name="primary-goal"][value="today"]')).toBeChecked();
  231 |     await page.reload();
  232 |     await expect(page).toHaveURL(/\/onboarding\/goals$/);
  233 |     await expect(
  234 |       page.getByRole('heading', { name: /Bạn muốn Takosan giúp việc gì trước/ }),
  235 |     ).toBeVisible();
  236 |     await expect(page.getByTestId('onboarding-goal-group')).toBeVisible();
  237 |   });
  238 | 
  239 |   test('legacy and redirect routes land on registered screens', async ({ page }) => {
  240 |     await reset(page);
  241 |     for (const [from, to] of [
  242 |       ['/profile', /\/me$/],
  243 |       ['/family', /\/me\/household$/],
  244 |       ['/settings', /\/settings\/app$/],
  245 |       ['/inventory', /\/fridge$/],
```