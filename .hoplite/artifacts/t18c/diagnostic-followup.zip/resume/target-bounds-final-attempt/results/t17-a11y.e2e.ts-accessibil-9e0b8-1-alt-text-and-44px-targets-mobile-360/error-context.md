# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: t17-a11y.e2e.ts >> accessibility certification >> canonical surfaces pass axe WCAG-AA, expose one h1, alt text and 44px targets
- Location: tests/e2e/t17-ui/t17-a11y.e2e.ts:78:3

# Error details

```
Error: interactive targets are at least 44×44

expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 9

- Array []
+ Array [
+   "fridge: a[flex items-center gap-2 ] 105x32",
+   "fridge: button[Ức gà] 46x23",
+   "fridge: button[Đậu phụ] 69x23",
+   "fridge: button[Trứng] 47x23",
+   "fridge: button[Phô mai] 66x23",
+   "fridge: button[Rau muống] 93x23",
+   "recipes: a[flex items-center gap-2 ] 105x32",
+ ]
```

# Page snapshot

```yaml
- generic [ref=f31e4]:
  - main [ref=f31e5]:
    - generic [ref=f31e6]:
      - generic [ref=f31e8]:
        - generic [ref=f31e9]:
          - button "Quay lại" [ref=f31e10] [cursor=pointer]
          - heading "Nâng cấp Takosan Plus" [level=1] [ref=f31e14]
        - generic [ref=f31e15]:
          - button "Thông báo" [ref=f31e16] [cursor=pointer]
          - button "Tài khoản cá nhân" [ref=f31e20] [cursor=pointer]:
            - img "Frigo Preview" [ref=f31e21]
      - generic [ref=f31e22]:
        - generic [ref=f31e24]:
          - generic [ref=f31e25]: Takosan Plus
          - heading "Nấu ăn thông minh hơn" [level=2] [ref=f31e30]
          - paragraph [ref=f31e31]: Mở khóa toàn bộ tính năng cao cấp cùng AI Chef
        - group "Gói Takosan Plus" [ref=f31e34]:
          - button [ref=f31e35] [cursor=pointer]:
            - paragraph [ref=f31e36]: Gói 1 Tháng
            - paragraph [ref=f31e37]: 49.000 VND
          - button [pressed] [ref=f31e38] [cursor=pointer]:
            - paragraph [ref=f31e39]: Gói 1 Năm
            - paragraph [ref=f31e40]: 499.000 VND
        - generic [ref=f31e41]:
          - heading "Quyền lợi thành viên:" [level=3] [ref=f31e42]
          - generic [ref=f31e43]: Không giới hạn số lượng nguyên liệu trong tủ lạnh
          - generic [ref=f31e48]: Không giới hạn lượt quét AI tủ lạnh & hóa đơn siêu thị OCR
          - generic [ref=f31e53]: Trọn bộ Takosan Planner lập thực đơn tuần tự động
          - generic [ref=f31e58]: AI Voice Sous Chef trợ lý nấu ăn rảnh tay thông minh
          - generic [ref=f31e63]: Đầy đủ 6 nền ẩm thực (Việt, Hàn, Nhật, Trung, Thái, Ý)
          - generic [ref=f31e68]: Gợi ý công thức nâng cao bởi DeepSeek AI Chef
          - generic [ref=f31e73]: Chia sẻ tủ lạnh gia đình không giới hạn thiết bị
        - button "Nâng cấp ngay với 499.000 VND" [ref=f31e79] [cursor=pointer]
  - navigation "Điều hướng chính" [ref=f31e83]:
    - list [ref=f31e84]:
      - listitem [ref=f31e85]:
        - link "Trang chủ" [ref=f31e86] [cursor=pointer]:
          - /url: /
      - listitem [ref=f31e91]:
        - link "Tủ lạnh" [ref=f31e92] [cursor=pointer]:
          - /url: /fridge
      - listitem [ref=f31e97]:
        - link "Quét AI" [ref=f31e98] [cursor=pointer]:
          - /url: /scan
          - generic [ref=f31e102]: Quét
      - listitem [ref=f31e103]:
        - link "Công thức" [ref=f31e104] [cursor=pointer]:
          - /url: /recipes
      - listitem [ref=f31e109]:
        - link "Thực đơn" [ref=f31e110] [cursor=pointer]:
          - /url: /planner
      - listitem [ref=f31e115]:
        - link "Tôi" [ref=f31e116] [cursor=pointer]:
          - /url: /me
```

# Test source

```ts
  30  |   h1Count: number; headingLevels: number[]; imagesWithoutAlt: number; smallTargets: string[];
  31  | }
  32  | 
  33  | async function auditSurface(page: Page, name: string, path: string): Promise<SurfaceReport> {
  34  |   const results = await new AxeBuilder({ page })
  35  |     .withTags(['wcag2a', 'wcag2aa', 'wcag21a', 'wcag21aa', 'best-practice'])
  36  |     // Google GSI / Turnstile iframes are external and blocked in the harness.
  37  |     .exclude('iframe')
  38  |     .analyze();
  39  |   const structure = await page.evaluate(() => {
  40  |     const headings = Array.from(document.querySelectorAll('h1, h2, h3, h4, h5, h6'))
  41  |       .filter((h) => (h as HTMLElement).offsetParent !== null || h.closest('[aria-modal]'))
  42  |       .map((h) => Number(h.tagName[1]));
  43  |     const imagesWithoutAlt = Array.from(document.querySelectorAll('img')).filter((img) => !img.hasAttribute('alt')).length;
  44  |     const small: string[] = [];
  45  |     for (const el of Array.from(document.querySelectorAll<HTMLElement>('a[href], button, input:not([type=hidden]), select, textarea, [role=button], [role=switch], [role=tab]'))) {
  46  |       if (el.closest('[aria-hidden="true"]')) continue;
  47  |       // Inline text links inside paragraphs are exempt (WCAG 2.5.8 inline exception).
  48  |       if (el.tagName === 'A' && el.closest('p, li')) continue;
  49  |       const targets = [el];
  50  |       if (el instanceof HTMLInputElement) targets.push(...Array.from(el.labels ?? []));
  51  |       const hitAreas = targets.flatMap((target) => {
  52  |         const rect = target.getBoundingClientRect();
  53  |         const style = getComputedStyle(target);
  54  |         if (rect.width === 0 || rect.height === 0 || style.visibility === 'hidden' || style.display === 'none') return [];
  55  |         // A positioned ::before with negative insets extends the hit area (Switch).
  56  |         const before = getComputedStyle(target, '::before');
  57  |         const inset = (v: string) => (before.content !== 'none' && before.position === 'absolute' ? Math.max(0, -parseFloat(v) || 0) : 0);
  58  |         return [{ width: rect.width + inset(before.left) + inset(before.right), height: rect.height + inset(before.top) + inset(before.bottom) }];
  59  |       });
  60  |       if (hitAreas.length === 0 || hitAreas.some(({ width, height }) => width >= 44 && height >= 44)) continue;
  61  |       const effective = hitAreas.reduce((largest, area) => area.width * area.height > largest.width * largest.height ? area : largest);
  62  |       small.push(`${el.tagName.toLowerCase()}[${el.getAttribute('aria-label') || el.textContent?.trim().slice(0, 24) || el.className.toString().slice(0, 24)}] ${Math.round(effective.width)}x${Math.round(effective.height)}`);
  63  |     }
  64  |     return { h1Count: document.querySelectorAll('h1').length, headingLevels: headings, imagesWithoutAlt, smallTargets: small };
  65  |   });
  66  |   return {
  67  |     name, path,
  68  |     violations: results.violations.map((v) => ({ id: v.id, impact: v.impact, help: v.help, nodes: v.nodes.length, targets: v.nodes.slice(0, 3).map((n) => `${n.target.join(' ')} :: ${n.html.slice(0, 160)} :: ${n.any[0]?.message ?? ''}`) })),
  69  |     ...structure,
  70  |   };
  71  | }
  72  | 
  73  | function seriousOrCritical(report: SurfaceReport) {
  74  |   return report.violations.filter((v) => v.impact === 'serious' || v.impact === 'critical');
  75  | }
  76  | 
  77  | test.describe('accessibility certification', () => {
  78  |   test('canonical surfaces pass axe WCAG-AA, expose one h1, alt text and 44px targets', async ({ page }, info) => {
  79  |     test.setTimeout(300_000);
  80  |     const reports: SurfaceReport[] = [];
  81  | 
  82  |     await page.goto('/landing');
  83  |     await page.context().clearCookies();
  84  |     await page.evaluate(() => { localStorage.clear(); sessionStorage.clear(); });
  85  |     for (const [name, path] of [['landing', '/landing'], ['auth', '/auth'], ['otp-empty', '/auth/verify']] as const) {
  86  |       await page.goto(path); await settle(page);
  87  |       reports.push(await auditSurface(page, name, path));
  88  |     }
  89  |     await reset(page);
  90  |     await page.goto('/onboarding'); await settle(page);
  91  |     reports.push(await auditSurface(page, 'onboarding', '/onboarding'));
  92  |     await completeOnboarding(page);
  93  |     await control(page, 't13-scans');
  94  |     await page.goto('/planner/new');
  95  |     await page.getByRole('button', { name: 'Tạo thực đơn' }).click();
  96  |     await expect(page.getByTestId('plan-revision')).toBeVisible();
  97  |     const planPath = new URL(page.url()).pathname;
  98  | 
  99  |     const surfaces: [string, string][] = [
  100 |       ['home', '/'], ['fridge', '/fridge'], ['fridge-detail', '/fridge/preview-stock-egg'],
  101 |       ['scan', '/scan'], ['scan-review', '/scan/t13b-preview-fridge/review'], ['receipt-review', '/scan/receipt-review?scanId=t13b-preview-receipt'],
  102 |       ['recipes', '/recipes'], ['recipe-detail', '/recipes/canh-chua-ca-loc-nam-bo'], ['cook', '/cook/canh-chua-ca-loc-nam-bo'],
  103 |       ['planner', '/planner'], ['planner-week', planPath], ['planner-shopping', `${planPath}/shopping`],
  104 |       ['shopping', '/shopping'], ['notifications', '/notifications'], ['profile', '/me'], ['preferences', '/me/preferences'],
  105 |       ['household', '/me/household'], ['planning-settings', '/settings/planning'], ['notification-preferences', '/settings/notifications'],
  106 |       ['app-settings', '/settings/app'], ['privacy', '/settings/privacy'], ['plus', '/plus'],
  107 |     ];
  108 |     for (const [name, path] of surfaces) {
  109 |       await page.goto(path); await settle(page);
  110 |       // Scan review polls until the seeded scan is ready; audit the settled state.
  111 |       if (name === 'scan-review') await expect(page.getByRole('button', { name: /Xác nhận nguyên liệu/ })).toBeEnabled();
  112 |       // Receipt review resolves its scan asynchronously; the disabled-CTA
  113 |       // frame is transitional, audit the settled state.
  114 |       if (name === 'receipt-review') await expect(page.getByRole('button', { name: /Nhập \d+ món vào Tủ lạnh/ })).toBeEnabled();
  115 |       reports.push(await auditSurface(page, name, path));
  116 |     }
  117 | 
  118 |     const summary = reports.map((r) => `${r.name}: axe=${r.violations.length} (serious+=${seriousOrCritical(r).length}) h1=${r.h1Count} noAlt=${r.imagesWithoutAlt} small=${r.smallTargets.length}`);
  119 |     // Written to the private output dir so the evidence is readable without
  120 |     // opening the trace; also attached for the reporter.
  121 |     await writeFile(info.outputPath('a11y-report.json'), JSON.stringify(reports, null, 2));
  122 |     await writeFile(info.outputPath('a11y-summary.txt'), summary.join('\n'));
  123 |     await info.attach('a11y-report', { path: info.outputPath('a11y-report.json'), contentType: 'application/json' });
  124 |     await info.attach('a11y-summary', { path: info.outputPath('a11y-summary.txt'), contentType: 'text/plain' });
  125 | 
  126 |     const failures = reports.flatMap((r) => seriousOrCritical(r).map((v) => `${r.name}: ${v.id} (${v.impact}) ×${v.nodes} — ${v.help} @ ${v.targets.join(' | ')}`));
  127 |     expect(failures, 'serious/critical axe violations').toEqual([]);
  128 |     expect(reports.filter((r) => r.h1Count !== 1).map((r) => `${r.name}: h1=${r.h1Count}`), 'exactly one h1 per surface').toEqual([]);
  129 |     expect(reports.filter((r) => r.imagesWithoutAlt > 0).map((r) => r.name), 'every image has an alt attribute').toEqual([]);
> 130 |     expect(reports.flatMap((r) => r.smallTargets.map((t) => `${r.name}: ${t}`)), 'interactive targets are at least 44×44').toEqual([]);
      |                                                                                                                            ^ Error: interactive targets are at least 44×44
  131 |   });
  132 | 
  133 |   test('OTP screen announces state changes: alerts for errors, status for success, group label for digits', async ({ page }) => {
  134 |     await page.goto('/landing');
  135 |     await page.context().clearCookies();
  136 |     await page.evaluate(() => { localStorage.clear(); sessionStorage.clear(); });
  137 |     await page.goto('/auth?mode=register');
  138 |     await page.getByLabel('Họ và tên', { exact: false }).fill('Người dùng kiểm thử tiếp cận');
  139 |     await page.getByLabel('Email', { exact: true }).fill('a11y-otp@example.test');
  140 |     await page.getByLabel('Mật khẩu', { exact: false }).first().fill('mat-khau-manh-1');
  141 |     await page.getByRole('button', { name: 'Tạo tài khoản & Nhận mã OTP' }).click();
  142 |     await expect(page).toHaveURL(/\/auth\/verify$/);
  143 |     // Delivery outcome is announced (status when sent, alert when not) — the
  144 |     // isolated preview has no mail provider, so either is legitimate here.
  145 |     await expect(page.getByRole('status').or(page.getByRole('alert')).first()).toBeVisible();
  146 |     const group = page.getByRole('group', { name: 'Mã OTP 6 chữ số' });
  147 |     await expect(group).toBeVisible();
  148 |     await expect(group.getByRole('textbox')).toHaveCount(6);
  149 |     for (let i = 1; i <= 6; i++) await expect(group.getByRole('textbox', { name: `Chữ số ${i} của 6` })).toBeVisible();
  150 |     // Incomplete submit announces an error and keeps focus in the form.
  151 |     await group.getByRole('textbox', { name: 'Chữ số 1 của 6' }).fill('4');
  152 |     await page.getByRole('button', { name: 'Xác thực & Hoàn tất' }).click();
  153 |     await expect(page.getByRole('alert')).toContainText('Vui lòng nhập đủ 6 chữ số mã OTP');
  154 |     const axe = await new AxeBuilder({ page }).withTags(['wcag2a', 'wcag2aa']).exclude('iframe').analyze();
  155 |     expect(axe.violations.filter((v) => v.impact === 'serious' || v.impact === 'critical').map((v) => `${v.id}: ${v.help}`)).toEqual([]);
  156 |   });
  157 | });
  158 | 
```