# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: t18c-gaps.e2e.ts >> shopping item checkbox toggles with Space through the existing API mutation
- Location: tests/e2e/t17-ui/t18c-gaps.e2e.ts:340:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('checkbox', { name: 'Đánh dấu đã mua: Hành tím kiểm thử', exact: true })
Expected: visible
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('checkbox', { name: 'Đánh dấu đã mua: Hành tím kiểm thử', exact: true }) with timeout 10000ms
  - waiting for getByRole('checkbox', { name: 'Đánh dấu đã mua: Hành tím kiểm thử', exact: true })

```

```yaml
- main:
  - button "Quay lại"
  - heading "Danh sách mua sắm" [level=1]
  - paragraph: Các nguyên liệu cần mua thêm
  - button "Thông báo"
  - button "Tài khoản cá nhân":
    - img "Frigo Preview"
  - textbox "Tên nguyên liệu cần mua":
    - /placeholder: "Thêm món: Hành tím, Tiêu, Nấm..."
  - combobox "Đơn vị":
    - option "quả/bìa" [selected]
    - option "gam (g)"
    - option "kg"
    - option "bó"
    - option "gói"
    - option "lít"
  - button "Thêm món vào danh sách"
  - button "Đánh dấu đã mua"
  - heading "Hành tím kiểm thử" [level=2]
  - paragraph: 2 piece
  - button "Xóa món"
- navigation "Điều hướng chính":
  - list:
    - listitem:
      - link "Trang chủ":
        - /url: /
    - listitem:
      - link "Tủ lạnh":
        - /url: /fridge
    - listitem:
      - link "Quét AI":
        - /url: /scan
        - text: Quét
    - listitem:
      - link "Công thức":
        - /url: /recipes
    - listitem:
      - link "Thực đơn":
        - /url: /planner
    - listitem:
      - link "Tôi":
        - /url: /me
```

# Test source

```ts
  286 | test('inventory detail and recipe recommendations are keyboard-navigable without merging row actions', async ({ page }, info) => {
  287 |   await reset(page);
  288 |   await page.goto('/fridge');
  289 | 
  290 |   const row = page.getByTestId('inventory-row').first();
  291 |   await expect(row).toBeVisible();
  292 |   const itemId = await row.getAttribute('data-item-id');
  293 |   expect(itemId).toBeTruthy();
  294 |   const heading = row.getByRole('heading').first();
  295 |   const ingredientName = (await heading.innerText()).trim();
  296 |   const ingredientButton = row.getByRole('button', { name: ingredientName, exact: true });
  297 |   await expect(ingredientButton).toBeVisible();
  298 |   await expect(heading).toContainText(ingredientName);
  299 | 
  300 |   const quantityButtons = row.getByRole('button', { name: /^(Tăng số lượng|Giảm số lượng)$/ });
  301 |   const deleteButton = row.getByRole('button', { name: 'Xóa nguyên liệu', exact: true });
  302 |   await expect(quantityButtons).toHaveCount(2);
  303 |   await expect(quantityButtons.first()).toBeVisible();
  304 |   await expect(deleteButton).toBeVisible();
  305 |   expect(await ingredientButton.locator('button').count()).toBe(0);
  306 | 
  307 |   let reachedByTab = false;
  308 |   for (let index = 0; index < 40; index += 1) {
  309 |     await page.keyboard.press('Tab');
  310 |     if (await ingredientButton.evaluate((element) => element === document.activeElement)) {
  311 |       reachedByTab = true;
  312 |       break;
  313 |     }
  314 |   }
  315 |   expect(reachedByTab, 'ingredient detail control is reachable with Tab').toBe(true);
  316 |   await expect(ingredientButton).toBeFocused();
  317 |   await page.keyboard.press('Enter');
  318 |   await expect(page).toHaveURL(new RegExp(`/(?:ingredients|fridge)/${escapeRegExp(itemId!)}$`));
  319 | 
  320 |   const recipeLink = page.locator('a[href^="/recipes/"]').first();
  321 |   await expect(recipeLink).toBeVisible();
  322 |   let recipeReachedByTab = false;
  323 |   for (let index = 0; index < 60; index += 1) {
  324 |     await page.keyboard.press('Tab');
  325 |     if (await recipeLink.evaluate((element) => element === document.activeElement)) {
  326 |       recipeReachedByTab = true;
  327 |       break;
  328 |     }
  329 |   }
  330 |   expect(recipeReachedByTab, 'recipe recommendation is reachable with Tab').toBe(true);
  331 |   await expect(recipeLink).toBeFocused();
  332 |   const recipeHref = await recipeLink.getAttribute('href');
  333 |   expect(recipeHref).toMatch(/^\/recipes\/[^/]+$/);
  334 |   await page.keyboard.press('Enter');
  335 |   await expect(page).toHaveURL(new RegExp(`${escapeRegExp(recipeHref!)}$`));
  336 | 
  337 |   await page.screenshot({ path: info.outputPath('inventory-detail-recipe-keyboard.png'), fullPage: true });
  338 | });
  339 | 
  340 | test('shopping item checkbox toggles with Space through the existing API mutation', async ({ page }, info) => {
  341 |   await reset(page);
  342 | 
  343 |   const item = {
  344 |     id: 't18c-keyboard-shopping-item',
  345 |     name: 'Hành tím kiểm thử',
  346 |     quantity: 2,
  347 |     unit: 'piece',
  348 |     isChecked: false,
  349 |     sourceRecipeTitle: '',
  350 |   };
  351 |   let patchCount = 0;
  352 |   let serverChecked = item.isChecked;
  353 | 
  354 |   await page.route('**/api/v1/shopping-list', async (route) => {
  355 |     if (route.request().method() !== 'GET') {
  356 |       await route.continue();
  357 |       return;
  358 |     }
  359 |     await route.fulfill({
  360 |       status: 200,
  361 |       contentType: 'application/json',
  362 |       body: JSON.stringify({ items: [{ ...item, isChecked: serverChecked }] }),
  363 |     });
  364 |   });
  365 |   await page.route('**/api/v1/shopping-list/items/t18c-keyboard-shopping-item', async (route) => {
  366 |     if (route.request().method() !== 'PATCH') {
  367 |       await route.continue();
  368 |       return;
  369 |     }
  370 |     patchCount += 1;
  371 |     const body = route.request().postDataJSON() as { isChecked?: boolean };
  372 |     expect(body).toEqual({ isChecked: true });
  373 |     serverChecked = body.isChecked === true;
  374 |     await route.fulfill({
  375 |       status: 200,
  376 |       contentType: 'application/json',
  377 |       body: JSON.stringify({
  378 |         success: true,
  379 |         item: { ...item, isChecked: serverChecked },
  380 |       }),
  381 |     });
  382 |   });
  383 | 
  384 |   await page.goto('/shopping');
  385 |   const checkbox = page.getByRole('checkbox', { name: `Đánh dấu đã mua: ${item.name}`, exact: true });
> 386 |   await expect(checkbox).toBeVisible();
      |                          ^ Error: expect(locator).toBeVisible() failed
  387 |   await expect(checkbox).toHaveAttribute('aria-checked', 'false');
  388 | 
  389 |   const mutation = page.waitForResponse((response) =>
  390 |     response.request().method() === 'PATCH' &&
  391 |     response.url().endsWith(`/shopping-list/items/${item.id}`),
  392 |   );
  393 |   await checkbox.press('Space');
  394 |   const mutationResponse = await mutation;
  395 |   expect(mutationResponse.status()).toBe(200);
  396 |   const mutationBody = await mutationResponse.json();
  397 |   expect(mutationBody).toMatchObject({
  398 |     success: true,
  399 |     item: { id: item.id, name: item.name, isChecked: true },
  400 |   });
  401 |   await expect(checkbox).toHaveAttribute('aria-checked', 'true');
  402 |   await expect(page.getByRole('checkbox', { name: `Bỏ đánh dấu đã mua: ${item.name}`, exact: true })).toBeVisible();
  403 |   expect(patchCount).toBe(1);
  404 | 
  405 |   await page.screenshot({ path: info.outputPath('shopping-keyboard-checkbox.png'), fullPage: true });
  406 | });
  407 | 
```