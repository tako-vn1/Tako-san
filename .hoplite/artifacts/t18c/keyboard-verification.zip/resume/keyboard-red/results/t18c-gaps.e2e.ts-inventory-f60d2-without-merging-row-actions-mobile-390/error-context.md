# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: t18c-gaps.e2e.ts >> inventory detail and recipe recommendations are keyboard-navigable without merging row actions
- Location: tests/e2e/t17-ui/t18c-gaps.e2e.ts:286:1

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByTestId('inventory-row').first().getByRole('button', { name: 'Ức gà', exact: true })
Expected: visible
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByTestId('inventory-row').first().getByRole('button', { name: 'Ức gà', exact: true }) with timeout 10000ms
  - waiting for getByTestId('inventory-row').first().getByRole('button', { name: 'Ức gà', exact: true })

```

```yaml
- main:
  - img "Takosan"
  - button "Thông báo"
  - button "Tài khoản cá nhân":
    - img "Frigo Preview"
  - heading "Tủ lạnh của tôi" [level=1]
  - paragraph: 🧊 5 nguyên liệu sẵn sàng nấu
  - button "Đối chiếu tủ lạnh Xem bằng chứng →"
  - textbox "Tìm theo tên nguyên liệu..."
  - button "Tất cả (5)"
  - button "Nên dùng sớm (1)"
  - button "Rau củ (1)"
  - button "Thịt"
  - button "Trứng"
  - button "Sữa/Bơ"
  - button "Gia vị"
  - button "Hải sản"
  - img "Ức gà"
  - heading "Ức gà" [level=2]
  - text: Chưa rõ hạn
  - paragraph: 300 g · Chưa rõ hạn
  - button "Giảm số lượng": –
  - text: 300 g
  - button "Tăng số lượng": +
  - button "Xóa nguyên liệu"
  - img "Đậu phụ"
  - heading "Đậu phụ" [level=2]
  - text: Chưa rõ hạn
  - paragraph: 200 g · Chưa rõ hạn
  - button "Giảm số lượng": –
  - text: 200 g
  - button "Tăng số lượng": +
  - button "Xóa nguyên liệu"
  - img "Trứng"
  - heading "Trứng" [level=2]
  - text: Chưa rõ hạn
  - paragraph: 2 piece · Chưa rõ hạn
  - button "Giảm số lượng": –
  - text: 2 piece
  - button "Tăng số lượng": +
  - button "Xóa nguyên liệu"
  - img "Phô mai"
  - heading "Phô mai" [level=2]
  - text: Chưa rõ hạn
  - paragraph: 200 g · Chưa rõ hạn
  - button "Giảm số lượng": –
  - text: 200 g
  - button "Tăng số lượng": +
  - button "Xóa nguyên liệu"
  - img "Rau muống"
  - heading "Rau muống" [level=2]
  - text: Chưa rõ hạn
  - paragraph: 1 bunch · Chưa rõ hạn
  - button "Giảm số lượng" [disabled]: –
  - text: 1 bunch
  - button "Tăng số lượng": +
  - button "Xóa nguyên liệu"
  - button "Thêm nguyên liệu"
- navigation "Điều hướng chính":
  - list:
    - listitem:
      - link "Trang chủ":
        - /url: /
    - listitem:
      - link "Tủ lạnh":
        - /url: /fridge
    - listitem:
      - link "Quét AI":
        - /url: /scan
        - text: Quét
    - listitem:
      - link "Công thức":
        - /url: /recipes
    - listitem:
      - link "Thực đơn":
        - /url: /planner
    - listitem:
      - link "Tôi":
        - /url: /me
```

# Test source

```ts
  197 |     const mascot = await page.getByRole('img', { name: 'Takosan cầm tủ lạnh' }).boundingBox();
  198 |     expect(heading && mascot).toBeTruthy();
  199 |     expect(heading!.x + heading!.width).toBeLessThanOrEqual(mascot!.x);
  200 |     await expectNoHorizontalOverflow(page);
  201 |     await page.screenshot({ path: info.outputPath(`landing-boundary-${width}.png`), fullPage: true });
  202 |   }
  203 | });
  204 | 
  205 | test('inventory and scan review fixed actions clear the active navigation shell', async ({ page }, info) => {
  206 |   await reset(page);
  207 | 
  208 |   await page.goto('/fridge');
  209 |   const inventoryAction = page.getByRole('button', { name: 'Thêm nguyên liệu', exact: true });
  210 |   await expect(inventoryAction).toBeVisible();
  211 |   await expectActionClearOfShell(page, inventoryAction);
  212 | 
  213 |   await control(page, 't13-scans');
  214 |   await page.goto('/scan/t13b-preview-fridge/review');
  215 |   const scanAction = page.getByRole('button', { name: /Xác nhận nguyên liệu/ });
  216 |   await expect(scanAction).toBeVisible();
  217 |   await expect(scanAction).toBeEnabled();
  218 |   await expectActionClearOfShell(page, scanAction);
  219 |   await expectNoHorizontalOverflow(page);
  220 | 
  221 |   await page.screenshot({ path: info.outputPath('fixed-actions-clearance.png'), fullPage: true });
  222 | });
  223 | 
  224 | test('Landing hero keeps real heading, mascot, and CTA in a tablet/desktop split', async ({ page }, info) => {
  225 |   await clearPublicSession(page);
  226 |   await page.goto('/landing');
  227 |   await settle(page);
  228 | 
  229 |   const heading = page.getByRole('heading', { level: 1 });
  230 |   const mascot = page.locator('img[alt="Takosan cầm tủ lạnh"]');
  231 |   const cta = page.getByRole('button', { name: 'Dùng thử Takosan ngay', exact: true });
  232 |   await expect(heading).toBeVisible();
  233 |   await expect(mascot).toBeVisible();
  234 |   await expect(cta).toBeVisible();
  235 |   await expectNoHorizontalOverflow(page);
  236 | 
  237 |   const width = page.viewportSize()!.width;
  238 |   if (width >= 640) {
  239 |     const [headingBox, mascotBox, ctaBox] = await Promise.all([
  240 |       heading.boundingBox(), mascot.boundingBox(), cta.boundingBox(),
  241 |     ]);
  242 |     expect(headingBox).not.toBeNull();
  243 |     expect(mascotBox).not.toBeNull();
  244 |     expect(ctaBox).not.toBeNull();
  245 |     expect(headingBox!.x + headingBox!.width).toBeLessThanOrEqual(mascotBox!.x + 1);
  246 |     expect(ctaBox!.x + ctaBox!.width).toBeLessThanOrEqual(mascotBox!.x + 1);
  247 |     expect(mascotBox!.x).toBeGreaterThan(headingBox!.x);
  248 |     await page.screenshot({ path: info.outputPath(`landing-split-${width}.png`), fullPage: true });
  249 |   }
  250 | });
  251 | 
  252 | test('Home primary and recommendation regions stay bounded and distinct on wide layouts', async ({ page }, info) => {
  253 |   await reset(page);
  254 |   await completeOnboarding(page);
  255 |   await page.goto('/');
  256 |   await settle(page);
  257 | 
  258 |   const primary = page.getByTestId('t18c-home-primary');
  259 |   const recommendations = page.getByTestId('t18c-home-recommendations');
  260 |   await expect(primary).toBeVisible();
  261 |   await expect(recommendations).toBeVisible();
  262 |   await expectNoHorizontalOverflow(page);
  263 | 
  264 |   const [mainBox, primaryBox, recommendationsBox] = await Promise.all([
  265 |     page.locator('main').first().boundingBox(),
  266 |     primary.boundingBox(),
  267 |     recommendations.boundingBox(),
  268 |   ]);
  269 |   expect(mainBox).not.toBeNull();
  270 |   expect(primaryBox).not.toBeNull();
  271 |   expect(recommendationsBox).not.toBeNull();
  272 |   expect(primaryBox!.x).toBeGreaterThanOrEqual(mainBox!.x);
  273 |   expect(primaryBox!.x + primaryBox!.width).toBeLessThanOrEqual(mainBox!.x + mainBox!.width + 1);
  274 |   expect(recommendationsBox!.x).toBeGreaterThanOrEqual(mainBox!.x);
  275 |   expect(recommendationsBox!.x + recommendationsBox!.width).toBeLessThanOrEqual(mainBox!.x + mainBox!.width + 1);
  276 | 
  277 |   if (page.viewportSize()!.width >= 768) {
  278 |     expect(primaryBox!.x + primaryBox!.width).toBeLessThanOrEqual(recommendationsBox!.x + 1);
  279 |   }
  280 |   if (page.viewportSize()!.width >= 1024) {
  281 |     expect(primaryBox!.width).toBeGreaterThan(recommendationsBox!.width);
  282 |     await page.screenshot({ path: info.outputPath(`home-regions-${page.viewportSize()!.width}.png`), fullPage: true });
  283 |   }
  284 | });
  285 | 
  286 | test('inventory detail and recipe recommendations are keyboard-navigable without merging row actions', async ({ page }, info) => {
  287 |   await reset(page);
  288 |   await page.goto('/fridge');
  289 | 
  290 |   const row = page.getByTestId('inventory-row').first();
  291 |   await expect(row).toBeVisible();
  292 |   const itemId = await row.getAttribute('data-item-id');
  293 |   expect(itemId).toBeTruthy();
  294 |   const heading = row.getByRole('heading').first();
  295 |   const ingredientName = (await heading.innerText()).trim();
  296 |   const ingredientButton = row.getByRole('button', { name: ingredientName, exact: true });
> 297 |   await expect(ingredientButton).toBeVisible();
      |                                  ^ Error: expect(locator).toBeVisible() failed
  298 |   await expect(heading).toContainText(ingredientName);
  299 | 
  300 |   const quantityButtons = row.getByRole('button', { name: /^(Tăng số lượng|Giảm số lượng)$/ });
  301 |   const deleteButton = row.getByRole('button', { name: 'Xóa nguyên liệu', exact: true });
  302 |   await expect(quantityButtons).toHaveCount(2);
  303 |   await expect(quantityButtons.first()).toBeVisible();
  304 |   await expect(deleteButton).toBeVisible();
  305 |   expect(await ingredientButton.locator('button').count()).toBe(0);
  306 | 
  307 |   let reachedByTab = false;
  308 |   for (let index = 0; index < 40; index += 1) {
  309 |     await page.keyboard.press('Tab');
  310 |     if (await ingredientButton.evaluate((element) => element === document.activeElement)) {
  311 |       reachedByTab = true;
  312 |       break;
  313 |     }
  314 |   }
  315 |   expect(reachedByTab, 'ingredient detail control is reachable with Tab').toBe(true);
  316 |   await expect(ingredientButton).toBeFocused();
  317 |   await page.keyboard.press('Enter');
  318 |   await expect(page).toHaveURL(new RegExp(`/(?:ingredients|fridge)/${escapeRegExp(itemId!)}$`));
  319 | 
  320 |   const recipeLink = page.locator('a[href^="/recipes/"]').first();
  321 |   await expect(recipeLink).toBeVisible();
  322 |   let recipeReachedByTab = false;
  323 |   for (let index = 0; index < 60; index += 1) {
  324 |     await page.keyboard.press('Tab');
  325 |     if (await recipeLink.evaluate((element) => element === document.activeElement)) {
  326 |       recipeReachedByTab = true;
  327 |       break;
  328 |     }
  329 |   }
  330 |   expect(recipeReachedByTab, 'recipe recommendation is reachable with Tab').toBe(true);
  331 |   await expect(recipeLink).toBeFocused();
  332 |   const recipeHref = await recipeLink.getAttribute('href');
  333 |   expect(recipeHref).toMatch(/^\/recipes\/[^/]+$/);
  334 |   await page.keyboard.press('Enter');
  335 |   await expect(page).toHaveURL(new RegExp(`${escapeRegExp(recipeHref!)}$`));
  336 | 
  337 |   await page.screenshot({ path: info.outputPath('inventory-detail-recipe-keyboard.png'), fullPage: true });
  338 | });
  339 | 
  340 | test('shopping item checkbox toggles with Space through the existing API mutation', async ({ page }, info) => {
  341 |   await reset(page);
  342 | 
  343 |   const item = {
  344 |     id: 't18c-keyboard-shopping-item',
  345 |     name: 'Hành tím kiểm thử',
  346 |     quantity: 2,
  347 |     unit: 'piece',
  348 |     isChecked: false,
  349 |     sourceRecipeTitle: '',
  350 |   };
  351 |   let patchCount = 0;
  352 |   let serverChecked = item.isChecked;
  353 | 
  354 |   await page.route('**/api/v1/shopping-list', async (route) => {
  355 |     if (route.request().method() !== 'GET') {
  356 |       await route.continue();
  357 |       return;
  358 |     }
  359 |     await route.fulfill({
  360 |       status: 200,
  361 |       contentType: 'application/json',
  362 |       body: JSON.stringify({ items: [{ ...item, isChecked: serverChecked }] }),
  363 |     });
  364 |   });
  365 |   await page.route('**/api/v1/shopping-list/items/t18c-keyboard-shopping-item', async (route) => {
  366 |     if (route.request().method() !== 'PATCH') {
  367 |       await route.continue();
  368 |       return;
  369 |     }
  370 |     patchCount += 1;
  371 |     const body = route.request().postDataJSON() as { isChecked?: boolean };
  372 |     expect(body).toEqual({ isChecked: true });
  373 |     serverChecked = body.isChecked === true;
  374 |     await route.fulfill({
  375 |       status: 200,
  376 |       contentType: 'application/json',
  377 |       body: JSON.stringify({
  378 |         success: true,
  379 |         item: { ...item, isChecked: serverChecked },
  380 |       }),
  381 |     });
  382 |   });
  383 | 
  384 |   await page.goto('/shopping');
  385 |   const checkbox = page.getByRole('checkbox', { name: `Đánh dấu đã mua: ${item.name}`, exact: true });
  386 |   await expect(checkbox).toBeVisible();
  387 |   await expect(checkbox).toHaveAttribute('aria-checked', 'false');
  388 | 
  389 |   const mutation = page.waitForResponse((response) =>
  390 |     response.request().method() === 'PATCH' &&
  391 |     response.url().endsWith(`/shopping-list/items/${item.id}`),
  392 |   );
  393 |   await checkbox.press('Space');
  394 |   const mutationResponse = await mutation;
  395 |   expect(mutationResponse.status()).toBe(200);
  396 |   const mutationBody = await mutationResponse.json();
  397 |   expect(mutationBody).toMatchObject({
```