# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: t18c-gaps.e2e.ts >> inventory detail and recipe recommendations are keyboard-navigable without merging row actions
- Location: tests/e2e/t17-ui/t18c-gaps.e2e.ts:286:1

# Error details

```
Test timeout of 60000ms exceeded.
```

```
Error: locator.evaluate: Test timeout of 60000ms exceeded.
Call log:
  - waiting for getByTestId('inventory-row').first().getByRole('button', { name: 'Ức gà', exact: true })

```

# Page snapshot

```yaml
- generic [ref=f3e4]:
  - main [ref=f3e5]:
    - generic [ref=f3e6]:
      - generic [ref=f3e8]:
        - link [ref=f3e9] [cursor=pointer]:
          - /url: /
          - img "Takosan" [ref=f3e10]
        - generic [ref=f3e11]:
          - button "Thông báo" [ref=f3e12] [cursor=pointer]
          - button "Tài khoản cá nhân" [ref=f3e16] [cursor=pointer]:
            - img "Frigo Preview" [ref=f3e17]
      - generic [ref=f3e18]:
        - generic [ref=f3e20]:
          - heading "Tủ lạnh của tôi" [level=1] [ref=f3e21]
          - paragraph [ref=f3e22]:
            - generic [ref=f3e23]: 🧊 5 nguyên liệu
            - text: sẵn sàng nấu
        - button "Đối chiếu tủ lạnh Xem bằng chứng →" [ref=f3e24] [cursor=pointer]:
          - generic [ref=f3e25]: Đối chiếu tủ lạnh
          - generic [ref=f3e26]: Xem bằng chứng →
        - textbox "Tìm theo tên nguyên liệu..." [ref=f3e31]
        - generic [ref=f3e32]:
          - button "Tất cả (5)" [ref=f3e33] [cursor=pointer]
          - button "Nên dùng sớm (1)" [ref=f3e34] [cursor=pointer]
          - button "Rau củ (1)" [ref=f3e35] [cursor=pointer]
          - button "Thịt" [ref=f3e36] [cursor=pointer]
          - button "Trứng" [ref=f3e37] [cursor=pointer]
          - button "Sữa/Bơ" [ref=f3e38] [cursor=pointer]
          - button "Gia vị" [ref=f3e39] [cursor=pointer]
          - button "Hải sản" [ref=f3e40] [cursor=pointer]
        - generic [ref=f3e41]:
          - generic [ref=f3e43] [cursor=pointer]:
            - generic [ref=f3e44]:
              - img "Đậu phụ" [ref=f3e46]
              - generic [ref=f3e47]:
                - generic [ref=f3e48]:
                  - heading [level=2] [ref=f3e49]:
                    - button "Đậu phụ" [ref=f3e50]
                  - generic [ref=f3e51]: Chưa rõ hạn
                - paragraph [ref=f3e54]: 200 g · Chưa rõ hạn
            - generic [ref=f3e55]:
              - generic [ref=f3e56]:
                - button "Giảm số lượng" [ref=f3e57]: –
                - generic [ref=f3e58]: 200 g
                - button "Tăng số lượng" [ref=f3e59]: +
              - button "Xóa nguyên liệu" [ref=f3e60]
          - generic [ref=f3e65] [cursor=pointer]:
            - generic [ref=f3e66]:
              - img "Trứng" [ref=f3e68]
              - generic [ref=f3e69]:
                - generic [ref=f3e70]:
                  - heading [level=2] [ref=f3e71]:
                    - button "Trứng" [ref=f3e72]
                  - generic [ref=f3e73]: Chưa rõ hạn
                - paragraph [ref=f3e76]: 2 piece · Chưa rõ hạn
            - generic [ref=f3e77]:
              - generic [ref=f3e78]:
                - button "Giảm số lượng" [ref=f3e79]: –
                - generic [ref=f3e80]: 2 piece
                - button "Tăng số lượng" [ref=f3e81]: +
              - button "Xóa nguyên liệu" [ref=f3e82]
          - generic [ref=f3e87] [cursor=pointer]:
            - generic [ref=f3e88]:
              - img "Phô mai" [ref=f3e90]
              - generic [ref=f3e91]:
                - generic [ref=f3e92]:
                  - heading [level=2] [ref=f3e93]:
                    - button "Phô mai" [ref=f3e94]
                  - generic [ref=f3e95]: Chưa rõ hạn
                - paragraph [ref=f3e98]: 200 g · Chưa rõ hạn
            - generic [ref=f3e99]:
              - generic [ref=f3e100]:
                - button "Giảm số lượng" [ref=f3e101]: –
                - generic [ref=f3e102]: 200 g
                - button "Tăng số lượng" [ref=f3e103]: +
              - button "Xóa nguyên liệu" [ref=f3e104]
          - generic [ref=f3e109] [cursor=pointer]:
            - generic [ref=f3e110]:
              - img "Rau muống" [ref=f3e112]
              - generic [ref=f3e113]:
                - generic [ref=f3e114]:
                  - heading [level=2] [ref=f3e115]:
                    - button "Rau muống" [ref=f3e116]
                  - generic [ref=f3e117]: Chưa rõ hạn
                - paragraph [ref=f3e120]: 1 bunch · Chưa rõ hạn
            - generic [ref=f3e121]:
              - generic [ref=f3e122]:
                - button "Giảm số lượng" [disabled] [ref=f3e123]: –
                - generic [ref=f3e124]: 1 bunch
                - button "Tăng số lượng" [ref=f3e125]: +
              - button "Xóa nguyên liệu" [ref=f3e126]
          - generic [ref=f3e131] [cursor=pointer]:
            - generic [ref=f3e132]:
              - img "Ức gà" [ref=f3e134]
              - generic [ref=f3e135]:
                - generic [ref=f3e136]:
                  - heading [level=2] [ref=f3e137]:
                    - button "Ức gà" [ref=f3e138]
                  - generic [ref=f3e139]: Chưa rõ hạn
                - paragraph [ref=f3e142]: 350 g · Chưa rõ hạn
            - generic [ref=f3e143]:
              - generic [ref=f3e144]:
                - button "Giảm số lượng" [ref=f3e145]: –
                - generic [ref=f3e146]: 350 g
                - button "Tăng số lượng" [ref=f3e147]: +
              - button "Xóa nguyên liệu" [ref=f3e148]
      - button "Thêm nguyên liệu" [active] [ref=f3e152] [cursor=pointer]
  - navigation "Điều hướng chính" [ref=f3e155]:
    - list [ref=f3e156]:
      - listitem [ref=f3e157]:
        - link "Trang chủ" [ref=f3e158] [cursor=pointer]:
          - /url: /
      - listitem [ref=f3e163]:
        - link "Tủ lạnh" [ref=f3e164] [cursor=pointer]:
          - /url: /fridge
      - listitem [ref=f3e170]:
        - link "Quét AI" [ref=f3e171] [cursor=pointer]:
          - /url: /scan
          - generic [ref=f3e175]: Quét
      - listitem [ref=f3e176]:
        - link "Công thức" [ref=f3e177] [cursor=pointer]:
          - /url: /recipes
      - listitem [ref=f3e182]:
        - link "Thực đơn" [ref=f3e183] [cursor=pointer]:
          - /url: /planner
      - listitem [ref=f3e188]:
        - link "Tôi" [ref=f3e189] [cursor=pointer]:
          - /url: /me
```

# Test source

```ts
  224 | test('Landing hero keeps real heading, mascot, and CTA in a tablet/desktop split', async ({ page }, info) => {
  225 |   await clearPublicSession(page);
  226 |   await page.goto('/landing');
  227 |   await settle(page);
  228 | 
  229 |   const heading = page.getByRole('heading', { level: 1 });
  230 |   const mascot = page.locator('img[alt="Takosan cầm tủ lạnh"]');
  231 |   const cta = page.getByRole('button', { name: 'Dùng thử Takosan ngay', exact: true });
  232 |   await expect(heading).toBeVisible();
  233 |   await expect(mascot).toBeVisible();
  234 |   await expect(cta).toBeVisible();
  235 |   await expectNoHorizontalOverflow(page);
  236 | 
  237 |   const width = page.viewportSize()!.width;
  238 |   if (width >= 640) {
  239 |     const [headingBox, mascotBox, ctaBox] = await Promise.all([
  240 |       heading.boundingBox(), mascot.boundingBox(), cta.boundingBox(),
  241 |     ]);
  242 |     expect(headingBox).not.toBeNull();
  243 |     expect(mascotBox).not.toBeNull();
  244 |     expect(ctaBox).not.toBeNull();
  245 |     expect(headingBox!.x + headingBox!.width).toBeLessThanOrEqual(mascotBox!.x + 1);
  246 |     expect(ctaBox!.x + ctaBox!.width).toBeLessThanOrEqual(mascotBox!.x + 1);
  247 |     expect(mascotBox!.x).toBeGreaterThan(headingBox!.x);
  248 |     await page.screenshot({ path: info.outputPath(`landing-split-${width}.png`), fullPage: true });
  249 |   }
  250 | });
  251 | 
  252 | test('Home primary and recommendation regions stay bounded and distinct on wide layouts', async ({ page }, info) => {
  253 |   await reset(page);
  254 |   await completeOnboarding(page);
  255 |   await page.goto('/');
  256 |   await settle(page);
  257 | 
  258 |   const primary = page.getByTestId('t18c-home-primary');
  259 |   const recommendations = page.getByTestId('t18c-home-recommendations');
  260 |   await expect(primary).toBeVisible();
  261 |   await expect(recommendations).toBeVisible();
  262 |   await expectNoHorizontalOverflow(page);
  263 | 
  264 |   const [mainBox, primaryBox, recommendationsBox] = await Promise.all([
  265 |     page.locator('main').first().boundingBox(),
  266 |     primary.boundingBox(),
  267 |     recommendations.boundingBox(),
  268 |   ]);
  269 |   expect(mainBox).not.toBeNull();
  270 |   expect(primaryBox).not.toBeNull();
  271 |   expect(recommendationsBox).not.toBeNull();
  272 |   expect(primaryBox!.x).toBeGreaterThanOrEqual(mainBox!.x);
  273 |   expect(primaryBox!.x + primaryBox!.width).toBeLessThanOrEqual(mainBox!.x + mainBox!.width + 1);
  274 |   expect(recommendationsBox!.x).toBeGreaterThanOrEqual(mainBox!.x);
  275 |   expect(recommendationsBox!.x + recommendationsBox!.width).toBeLessThanOrEqual(mainBox!.x + mainBox!.width + 1);
  276 | 
  277 |   if (page.viewportSize()!.width >= 768) {
  278 |     expect(primaryBox!.x + primaryBox!.width).toBeLessThanOrEqual(recommendationsBox!.x + 1);
  279 |   }
  280 |   if (page.viewportSize()!.width >= 1024) {
  281 |     expect(primaryBox!.width).toBeGreaterThan(recommendationsBox!.width);
  282 |     await page.screenshot({ path: info.outputPath(`home-regions-${page.viewportSize()!.width}.png`), fullPage: true });
  283 |   }
  284 | });
  285 | 
  286 | test('inventory detail and recipe recommendations are keyboard-navigable without merging row actions', async ({ page }, info) => {
  287 |   await reset(page);
  288 |   await page.goto('/fridge');
  289 | 
  290 |   const row = page.getByTestId('inventory-row').first();
  291 |   await expect(row).toBeVisible();
  292 |   const itemId = await row.getAttribute('data-item-id');
  293 |   expect(itemId).toBeTruthy();
  294 |   const heading = row.getByRole('heading').first();
  295 |   const ingredientName = (await heading.innerText()).trim();
  296 |   const ingredientButton = row.getByRole('button', { name: ingredientName, exact: true });
  297 |   await expect(ingredientButton).toBeVisible();
  298 |   await expect(heading).toContainText(ingredientName);
  299 | 
  300 |   const quantityButtons = row.getByRole('button', { name: /^(Tăng số lượng|Giảm số lượng)$/ });
  301 |   const deleteButton = row.getByRole('button', { name: 'Xóa nguyên liệu', exact: true });
  302 |   await expect(quantityButtons).toHaveCount(2);
  303 |   await expect(quantityButtons.first()).toBeVisible();
  304 |   await expect(deleteButton).toBeVisible();
  305 |   expect(await ingredientButton.locator('button').count()).toBe(0);
  306 | 
  307 |   const update = page.waitForResponse((response) =>
  308 |     response.request().method() === 'PATCH' && response.url().endsWith(`/inventory/${itemId}`),
  309 |   );
  310 |   await row.getByRole('button', { name: 'Tăng số lượng', exact: true }).click();
  311 |   expect((await update).status()).toBe(200);
  312 |   await expect(page).toHaveURL(/\/fridge$/);
  313 |   await deleteButton.click();
  314 |   const confirmation = page.getByRole('alertdialog', { name: 'Xóa nguyên liệu?' });
  315 |   await expect(confirmation).toBeVisible();
  316 |   await expect(page).toHaveURL(/\/fridge$/);
  317 |   await confirmation.getByRole('button', { name: 'Hủy', exact: true }).click();
  318 |   await expect(confirmation).toBeHidden();
  319 |   await page.screenshot({ path: info.outputPath('inventory-keyboard-controls.png'), fullPage: true });
  320 | 
  321 |   let reachedByTab = false;
  322 |   for (let index = 0; index < 40; index += 1) {
  323 |     await page.keyboard.press('Tab');
> 324 |     if (await ingredientButton.evaluate((element) => element === document.activeElement)) {
      |                                ^ Error: locator.evaluate: Test timeout of 60000ms exceeded.
  325 |       reachedByTab = true;
  326 |       break;
  327 |     }
  328 |   }
  329 |   expect(reachedByTab, 'ingredient detail control is reachable with Tab').toBe(true);
  330 |   await expect(ingredientButton).toBeFocused();
  331 |   await page.keyboard.press('Enter');
  332 |   await expect(page).toHaveURL(new RegExp(`/(?:ingredients|fridge)/${escapeRegExp(itemId!)}$`));
  333 | 
  334 |   const recipeLink = page.locator('a[href^="/recipes/"]').first();
  335 |   await expect(recipeLink).toBeVisible();
  336 |   let recipeReachedByTab = false;
  337 |   for (let index = 0; index < 60; index += 1) {
  338 |     await page.keyboard.press('Tab');
  339 |     if (await recipeLink.evaluate((element) => element === document.activeElement)) {
  340 |       recipeReachedByTab = true;
  341 |       break;
  342 |     }
  343 |   }
  344 |   expect(recipeReachedByTab, 'recipe recommendation is reachable with Tab').toBe(true);
  345 |   await expect(recipeLink).toBeFocused();
  346 |   const recipeHref = await recipeLink.getAttribute('href');
  347 |   expect(recipeHref).toMatch(/^\/recipes\/[^/]+$/);
  348 |   await page.keyboard.press('Enter');
  349 |   await expect(page).toHaveURL(new RegExp(`${escapeRegExp(recipeHref!)}$`));
  350 | 
  351 |   await page.screenshot({ path: info.outputPath('inventory-detail-recipe-keyboard.png'), fullPage: true });
  352 | });
  353 | 
  354 | test('shopping item checkbox toggles with Space through the existing API mutation', async ({ page }, info) => {
  355 |   await reset(page);
  356 | 
  357 |   const item = {
  358 |     id: 't18c-keyboard-shopping-item',
  359 |     name: 'Hành tím kiểm thử',
  360 |     quantity: 2,
  361 |     unit: 'piece',
  362 |     isChecked: false,
  363 |     sourceRecipeTitle: '',
  364 |   };
  365 |   let patchCount = 0;
  366 |   let serverChecked = item.isChecked;
  367 | 
  368 |   await page.route('**/api/v1/shopping-list', async (route) => {
  369 |     if (route.request().method() !== 'GET') {
  370 |       await route.continue();
  371 |       return;
  372 |     }
  373 |     await route.fulfill({
  374 |       status: 200,
  375 |       contentType: 'application/json',
  376 |       body: JSON.stringify({ items: [{ ...item, isChecked: serverChecked }] }),
  377 |     });
  378 |   });
  379 |   await page.route('**/api/v1/shopping-list/items/t18c-keyboard-shopping-item', async (route) => {
  380 |     if (route.request().method() !== 'PATCH') {
  381 |       await route.continue();
  382 |       return;
  383 |     }
  384 |     patchCount += 1;
  385 |     const body = route.request().postDataJSON() as { isChecked?: boolean };
  386 |     expect(body).toEqual({ isChecked: true });
  387 |     serverChecked = body.isChecked === true;
  388 |     await route.fulfill({
  389 |       status: 200,
  390 |       contentType: 'application/json',
  391 |       body: JSON.stringify({
  392 |         success: true,
  393 |         item: { ...item, isChecked: serverChecked },
  394 |       }),
  395 |     });
  396 |   });
  397 | 
  398 |   await page.goto('/shopping');
  399 |   const checkbox = page.getByRole('checkbox', { name: `Đánh dấu đã mua: ${item.name}`, exact: true });
  400 |   await expect(checkbox).toBeVisible();
  401 |   await expect(checkbox).toHaveAttribute('aria-checked', 'false');
  402 | 
  403 |   const mutation = page.waitForResponse((response) =>
  404 |     response.request().method() === 'PATCH' &&
  405 |     response.url().endsWith(`/shopping-list/items/${item.id}`),
  406 |   );
  407 |   await checkbox.press('Space');
  408 |   const mutationResponse = await mutation;
  409 |   expect(mutationResponse.status()).toBe(200);
  410 |   const mutationBody = await mutationResponse.json();
  411 |   expect(mutationBody).toMatchObject({
  412 |     success: true,
  413 |     item: { id: item.id, name: item.name, isChecked: true },
  414 |   });
  415 |   const checkedItem = page.getByRole('checkbox', { name: `Bỏ đánh dấu đã mua: ${item.name}`, exact: true });
  416 |   await expect(checkedItem).toHaveAttribute('aria-checked', 'true');
  417 |   await expect(checkedItem).toBeVisible();
  418 |   expect(patchCount).toBe(1);
  419 | 
  420 |   await page.screenshot({ path: info.outputPath('shopping-keyboard-checkbox.png'), fullPage: true });
  421 | });
  422 | 
```