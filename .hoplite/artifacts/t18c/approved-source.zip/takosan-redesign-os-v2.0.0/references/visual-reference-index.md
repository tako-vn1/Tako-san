# Visual reference index

| Board | Screens | Authority |
| --- | --- | --- |
| `board-01-entry-home-scan.png` | 01–09 | Visual direction for entry, onboarding, Home, camera and scan review |
| `board-02-food-planner.png` | 10–18 | Visual direction for inventory, recipes, cooking, shopping and Planner |
| `board-03-account-settings.png` | 19–27 | Visual direction for account, settings, notifications, privacy and Plus |

Boards illustrate hierarchy, tone, density, imagery, and relationships. They do not authorize fake user names, prices, dates, counts, household records, notification channels, entitlements, or backend behavior. Responsive desktop/tablet layouts are defined by the layout and screen specifications, not by enlarging the phone mockups.
