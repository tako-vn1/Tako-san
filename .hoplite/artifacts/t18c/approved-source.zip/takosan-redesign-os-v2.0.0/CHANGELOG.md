# Changelog

## 2.0.0 — 2026-09-19

- Established the T17 Takosan UI V2 design and engineering contract.
- Added semantic tokens, primitives, motion, responsive AppShell and state rules.
- Added route/IA contracts and 27 screen specifications.
- Embedded the canonical Takosan brand kit and three UI boards.
- Added migration, protected-boundary, checkpoint, visual regression, accessibility and certification contracts.
- Added start, recovery and session handoff prompts for credit/session continuity.
