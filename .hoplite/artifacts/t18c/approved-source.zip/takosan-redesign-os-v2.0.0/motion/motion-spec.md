# Motion architecture

Prefer `motion/react` when compatible with the existing runtime. Provide a single `MotionProvider` wrapping `<MotionConfig reducedMotion="user">` and export `PageTransition`, `Fade`, `Slide`, `ScalePress`, `Presence` or `AnimatedPresence`, `AnimatedList`, `AnimatedSheet`, `AnimatedDialog`, and `SharedIndicator`.

Use token names rather than local duration/easing literals. Motion may communicate entry, directional progress, insertion/removal, continuity, modal ownership, or direct manipulation feedback. It must not delay primary actions or re-run on query refresh.

Required: auth state transitions, onboarding forward/back, navigation indicator, inventory list layout, scan state transition, recipe-to-detail continuity where technically safe, cooking step direction, planner layout change, sheet/dialog enter/exit, and toast stacking.

Rejected: page-wide parallax, perpetual mascot motion, stagger on every visit, indiscriminate `transition-all`, more than one simultaneous primary motion story, or motion that hides truth updates.
