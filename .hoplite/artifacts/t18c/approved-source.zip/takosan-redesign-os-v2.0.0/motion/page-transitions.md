# Page transitions

| Context | Enter | Exit | Notes |
| --- | --- | --- | --- |
| Standard route | fade + 8px rise, normal | fade, fast | Keep shell/navigation stable. |
| Auth state | fade + 12px horizontal | opposite direction | Use presence; focus first meaningful heading. |
| Onboarding forward | +24px to 0 | 0 to -24px | Reverse on Back. |
| Cooking step | horizontal 24px | horizontal -24px | Direction follows previous/next. |
| Scan camera→processing→review | contextual crossfade | contextual | Preserve thumbnail/capture context. |
| Modal | backdrop fade + panel scale 0.98 | reverse | Focus trap and return required. |
| Sheet | backdrop fade + spring slide | downward exit | Drag dismissal only if accessible alternative exists. |

Never animate the responsive shell between breakpoints. Route transitions must not block initial data rendering.
