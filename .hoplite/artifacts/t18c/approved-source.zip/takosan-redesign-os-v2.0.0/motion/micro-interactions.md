# Micro-interactions

- Buttons: press scale no lower than `0.98`; no bounce on destructive actions.
- Chips/tabs/navigation: animate shared selection indicator, not label position.
- Quantity controls: brief value fade/slide; server truth and pending/error states remain visible.
- Inventory add/remove/reorder: layout animation keyed by stable server identity.
- Favorite/check controls: scale/color feedback after accepted local intent; roll back visibly on server failure.
- Toasts: enter from nearest safe edge, stack by layout, never cover primary bottom CTA.
- Skeletons: subtle opacity pulse only; respect reduced motion.
- Mascot hero: one gentle first entrance, no looping.
