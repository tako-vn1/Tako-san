# Reduced motion contract

Honor both `prefers-reduced-motion` and Motion's `reducedMotion="user"`.

When reduced motion is requested:

- replace spatial page movement with instant state change or short opacity fade;
- disable layout spring travel and press scaling;
- stop skeleton shimmer and looping animation;
- keep progress, focus, loading, and success semantics intact;
- never make content unavailable because animation was disabled.

Automated tests must emulate reduced motion on at least auth, onboarding, sheet/dialog, cooking, and Planner flows.
