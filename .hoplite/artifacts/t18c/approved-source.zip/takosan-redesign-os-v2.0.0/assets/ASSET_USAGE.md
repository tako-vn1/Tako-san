# Asset usage

Read `brand-kit/docs/AI-AGENT-RENDERING.md` before using assets. The vector mascot is canonical for UI; the 3D master is a raster illustration source, not a reason to generate inconsistent poses. Use mascots for onboarding, empty states, success, and restrained landing support—not as decoration in every card.

Copy only required production assets into the repository's established public/static asset location. Preserve filenames where practical and create a typed asset map if the frontend architecture supports it. Do not import `source/build.py` into application runtime. Boards and previews are QA references, not production payloads.
