from pathlib import Path
import json, subprocess, shutil, hashlib, zipfile, html
ROOT=Path(__file__).resolve().parents[1]
C={'coral':'#FF7B6B','green':'#2E7D5B','navy':'#1F2937','cream':'#FFF8F3','mint':'#DFF4E6','yellow':'#FFC857'}
for d in ['logo','mascot','ui-icons','app-icons','marketing','social','design-tokens','docs','preview','export/png','source']:(ROOT/d).mkdir(parents=True,exist_ok=True)
def save(p,s): (ROOT/p).write_text(s)
def svg(body,w=512,h=512):return f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}">{body}</svg>'
def path(d,fill):return f'<path d="{d}" fill="{fill}"/>'
def stroke(d,col='#1F2937',sw=8):return f'<path d="{d}" fill="none" stroke="{col}" stroke-width="{sw}" stroke-linecap="round" stroke-linejoin="round"/>'
def rect(x,y,w,h,r,col):return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" fill="{col}"/>'
def circle(x,y,r,col):return f'<circle cx="{x}" cy="{y}" r="{r}" fill="{col}"/>'
def text(t,x,y,size=24,col='#1F2937'):return f'<text x="{x}" y="{y}" fill="{col}" font-family="DejaVu Sans,sans-serif" font-size="{size}">{html.escape(t)}</text>'
leaf=lambda col: path('M328 132 C323 91 350 64 397 68 C398 112 370 142 328 132Z',col)
def mascot(pose='neutral',mono=None,micro=False):
 coral=mono or C['coral'];green=mono or C['green'];hat=mono or C['cream'];face=C['cream'] if mono else C['navy']
 a='<g id="takosan-canonical-symbol">'
 a+=path('M162 351 C124 350 118 393 83 378 C66 371 71 353 60 351 C41 346 34 371 46 394 C66 434 126 431 164 404 C143 448 176 467 206 447 C227 433 238 411 256 397 C274 411 285 433 306 447 C336 467 369 448 348 404 C386 431 446 434 466 394 C478 371 471 346 452 351 C441 353 446 371 429 378 C394 393 388 350 350 351Z',coral)
 a+=path('M99 268 C99 179 159 126 256 126 C353 126 413 179 413 268 C413 355 359 399 256 399 C153 399 99 355 99 268Z',coral)
 if not mono and not micro:a+=circle(160,320,15,'#F96B60')+circle(352,320,15,'#F96B60')
 if pose=='celebrate':a+=stroke('M179 291 Q191 268 203 291 M309 291 Q321 268 333 291',face,10)
 elif pose=='wave':a+=f'<ellipse cx="190" cy="282" rx="17" ry="22" fill="{face}"/>'+stroke('M309 285 Q321 274 333 285',face,9)
 else:
  for x in [190,322]:
   a+=f'<ellipse cx="{x}" cy="282" rx="17" ry="22" fill="{face}"/>'
   if not mono and not micro:a+=circle(x+5,274,4.5,C['cream'])
 a+=stroke('M242 303 Q256 322 270 303',face,8)
 a+=path('M177 137 C139 140 124 113 135 88 C144 67 163 62 186 71 C182 35 209 16 240 21 C267 16 293 37 290 70 C318 57 346 73 349 102 C353 128 331 141 311 139 L309 162 Q247 148 179 162Z',hat)
 if not mono:a+=stroke('M181 142 Q247 130 307 142','#E7DBD1',3)
 a+=leaf(green)
 if mono:a+=stroke('M337 123 Q356 101 383 82',C['cream'],5)
 a+='</g>'
 if pose in ['fridge','shopping','calendar','recipe','cooking']:
  a+=rect(200,339,112,112,20,C['mint'])
  if pose=='fridge':a+=stroke('M219 359 V381 M219 404 V426',C['green'],7)+stroke('M203 391 H309',C['green'],3)
  elif pose=='calendar':a+=stroke('M217 361 H295 M232 345 V370 M280 345 V370',C['green'],6)+stroke('M230 405 L247 422 L280 390',C['green'],7)
  elif pose=='shopping':a+=stroke('M230 366 V350 Q256 322 282 350 V366',C['green'],7)+stroke('M238 396 L253 410 L279 380',C['green'],7)
  elif pose=='recipe':a+=stroke('M255 356 V433 M218 367 Q238 359 255 367 Q272 359 294 367 M222 389 H242 M271 389 H290',C['green'],5)
  else:a+=path('M216 387 H297 Q291 427 256 427 Q222 427 216 387Z',C['green'])+stroke('M234 374 Q225 364 237 354 M260 374 Q251 364 263 354',C['green'],5)
  a+=f'<ellipse cx="203" cy="407" rx="23" ry="18" fill="{coral}"/><ellipse cx="309" cy="407" rx="23" ry="18" fill="{coral}"/>'
 if pose=='leaf':a+='<g transform="translate(-170 260) scale(.95)">'+leaf(C['green'])+'</g>'
 if pose=='thinking':a+=circle(426,216,7,C['green'])+circle(449,187,11,C['mint'])+circle(472,149,18,C['mint'])
 if pose=='celebrate':a+=stroke('M65 209 L52 194 M447 209 L460 194 M75 254 H52 M437 254 H460',C['green'],8)
 if pose=='wave':a+=stroke('M439 316 Q457 303 455 288 M458 328 Q483 311 481 288',C['green'],6)
 return a
letters={'T':'M5 8 H45 M25 8 V61','A':'M3 61 L23 8 Q25 4 27 8 L47 61 M12 40 H38','K':'M6 8 V61 M45 8 L7 35 L46 61','O':'M26 6 C-2 6 -2 63 26 63 C54 63 54 6 26 6Z','S':'M45 13 C12 -8 -10 28 23 34 C62 40 47 76 6 57','N':'M5 61 V8 L45 61 V8'}
def word(col=C['navy']):return '<g id="takosan-custom-wordmark">'+''.join(f'<g transform="translate({i*64} 0)">'+stroke(letters[ch],col,12)+'</g>' for i,ch in enumerate('TAKOSAN'))+'</g>'
save('logo/takosan-symbol.svg',svg(mascot()))
save('logo/takosan-symbol-micro.svg',svg(mascot(micro=True)))
save('logo/takosan-wordmark.svg',svg('<g transform="translate(10 5)">'+word()+'</g>',465,82))
for variant,col in [('primary',C['navy']),('white','#FFFFFF'),('monochrome',C['navy'])]:
 m=mascot(mono=col) if variant!='primary' else mascot()
 save(f'logo/takosan-logo-{variant}.svg',svg('<g transform="translate(44 0)">'+m+'</g><g transform="translate(78 480)">'+word(col)+'</g>',600,568))
 save(f'logo/takosan-logo-horizontal-{variant}.svg',svg('<g transform="translate(0 0) scale(.42)">'+m+'</g><g transform="translate(242 78)">'+word(col)+'</g>',712,218))
for pose in ['neutral','wave','fridge','leaf','cooking','calendar','shopping','celebrate','thinking','recipe']:save(f'mascot/takosan-{pose}.svg',svg(mascot(pose)))
for mode,bg in [('light',C['cream']),('dark',C['navy']),('mint',C['mint'])]:save(f'app-icons/takosan-app-icon-{mode}.svg',svg(rect(0,0,1024,1024,0,bg)+'<g transform="translate(130 140) scale(1.49)">'+mascot(micro=True)+'</g>',1024,1024))
save('app-icons/takosan-adaptive-foreground.svg',svg('<g transform="translate(264 264) scale(.97)">'+mascot(micro=True)+'</g>',1024,1024))
save('app-icons/takosan-adaptive-background.svg',svg(rect(0,0,1024,1024,0,C['cream']),1024,1024))
save('app-icons/favicon.svg',svg(mascot(micro=True)))
icons={
'fridge':'M6 3 H18 V21 H6Z M6 10 H18 M9 6 V8 M9 13 V17',
'inventory':'M4 7 L12 3 L20 7 V18 L12 22 L4 18Z M4 7 L12 11 L20 7 M12 11 V22',
'expiry':'M12 3 A9 9 0 1 0 21 12 M12 7 V12 L15 14 M17 3 H22 V8 M22 3 L17 8',
'recipe':'M3 5 Q7 2 12 5 Q17 2 21 5 V20 Q17 17 12 20 Q7 17 3 20Z M12 5 V20 M6 9 H9 M15 9 H18',
'chef':'M7 15 C1 14 2 6 7 6 C7 1 17 1 17 6 C22 6 23 14 17 15 V21 H7Z M7 17 H17',
'calendar':'M4 5 H20 V21 H4Z M8 3 V7 M16 3 V7 M4 10 H20 M8 14 H10 M14 14 H16 M8 17 H10',
'meal-plan':'M4 5 H20 V21 H4Z M8 3 V7 M16 3 V7 M4 10 H20 M8 16 L11 19 L17 13',
'shopping-cart':'M2 3 H5 L8 16 H19 L22 7 H6 M10 21 H10.1 M18 21 H18.1',
'shopping-list':'M8 4 H5 V22 H19 V4 H16 M8 2 H16 V6 H8Z M8 11 L9 12 L11 10 M14 11 H16 M8 17 L9 18 L11 16 M14 17 H16',
'nutrition':'M12 8 C4 2 1 10 5 17 C9 24 11 19 12 20 C13 19 15 24 19 17 C23 10 20 2 12 8Z M12 8 C12 3 15 2 18 2',
'leaf':'M4 20 C-2 9 8 3 21 3 C22 16 15 23 4 20Z M4 20 L16 8',
'waste':'M6 7 H18 L17 22 H7Z M4 7 H20 M9 7 V3 H15 V7 M10 11 V18 M14 11 V18',
'heart':'M12 21 L4 13 C-3 5 7 -1 12 7 C17 -1 27 5 20 13Z',
'camera':'M3 7 H7 L9 4 H15 L17 7 H21 V21 H3Z M16 14 A4 4 0 1 1 8 14 A4 4 0 1 1 16 14',
'scan':'M3 8 V3 H8 M16 3 H21 V8 M21 16 V21 H16 M8 21 H3 V16 M2 12 H22 M8 7 H16 M8 17 H16',
'spark':'M12 2 L15 9 L22 12 L15 15 L12 22 L9 15 L2 12 L9 9Z',
'search':'M17 10 A7 7 0 1 1 3 10 A7 7 0 1 1 17 10 M15 15 L22 22',
'profile':'M16 7 A4 4 0 1 1 8 7 A4 4 0 1 1 16 7 M4 22 V19 C4 10 20 10 20 19 V22',
'settings':'M4 6 H20 M4 12 H20 M4 18 H20 M8 3 V9 M16 9 V15 M10 15 V21',
'notification':'M5 17 H19 C17 14 18 12 18 9 C18 1 6 1 6 9 C6 12 7 14 5 17Z M9 21 H15',
'home':'M2 11 L12 2 L22 11 M5 9 V22 H19 V9 M10 22 V15 H14 V22',
'budget':'M3 5 H21 V21 H3Z M3 5 V2 H18 M16 11 H22 V16 H16Z',
'check':'M4 12 L10 18 L21 5',
'close':'M5 5 L19 19 M19 5 L5 19'}
for name,d in icons.items():save(f'ui-icons/takosan-icon-{name}.svg',svg(stroke(d,'currentColor',1.8),24,24))
tokens={'version':'1.1.0','color':C,'semantic':{'actionPrimary':C['green'],'onActionPrimary':'#FFFFFF','actionAccent':C['coral'],'onActionAccent':C['navy'],'text':C['navy'],'surface':C['cream'],'success':C['green']},'radius':{'sm':10,'md':16,'lg':24,'xl':32},'spacing':[4,8,12,16,24,32,48,64],'typography':{'ui':'Nunito, system-ui, sans-serif','fallback':'system-ui, sans-serif','wordmark':'Custom outlined geometry — use supplied SVG'},'icon':{'viewBox':'0 0 24 24','strokeWidth':1.8,'linecap':'round','linejoin':'round'}}
save('design-tokens/brand-tokens.json',json.dumps(tokens,indent=2))
save('design-tokens/brand-tokens.css',':root {\n'+''.join(f'  --takosan-{k}: {v};\n' for k,v in C.items())+'  --takosan-action: var(--takosan-green);\n  --takosan-on-accent: var(--takosan-navy);\n'+''.join(f'  --takosan-radius-{k}: {v}px;\n' for k,v in tokens['radius'].items())+'}\n')
save('design-tokens/tailwind-brand-preset.ts','export default '+json.dumps({'theme':{'extend':{'colors':{'takosan':C},'borderRadius':{k:f'{v}px' for k,v in tokens['radius'].items()}}}},indent=2)+';\n')
# Editable campaign files use the vector master; live campaign text is intentionally editable.
for name,w,h,headline,sub,pose in [('social-square',1080,1080,'Good food.','Brighter days.','fridge'),('social-portrait',1080,1350,'Use what you have.','Make something wonderful.','cooking'),('story',1080,1920,'Plan once.','Eat better all week.','calendar'),('website-hero',1600,900,'Your kitchen, in sync.','Know your food. Plan your week. Waste less.','fridge'),('launch-banner',1600,900,'Meet Takosan.','A little help. A happier kitchen.','wave'),('play-store-cover',1024,500,'Good food.','Brighter days.','fridge'),('app-store-cover',1290,2796,'Your kitchen, in sync.','Know your food. Plan your week.','calendar')]:
 if w>h:
  body=rect(0,0,w,h,0,C['cream'])+f'<g transform="translate(64 60) scale(.6)">{word()}</g>'+text(headline,64,h*.43,min(54,w*.043))+text(sub,64,h*.43+54,min(25,w*.018))+f'<g transform="translate({w*.61} {h*.16}) scale({h*.0015})">{mascot(pose)}</g>'
 else:
  s=w*.0016; y=h*.34
  body=rect(0,0,w,h,0,C['cream'])+f'<g transform="translate(80 78)">{word()}</g>'+text(headline,80,250,54)+text(sub,80,321,40)+f'<g transform="translate({(w-512*s)/2} {y}) scale({s})">{mascot(pose)}</g>'+text('GOOD FOOD, BRIGHTER DAYS.',80,h-86,23)
 save(f'{"social" if name.startswith("social") or name=="story" else "marketing"}/takosan-{name}.svg',svg(body,w,h))
# Brand board — real exported assets, not generated mockups.
b=rect(0,0,1600,1480,0,C['cream'])+text('TAKOSAN / BRAND SYSTEM',64,60,18)+text('A little help. A happier kitchen.',64,117,39)+text('01 / CORE IDENTITY',64,180,15)
b+=rect(64,208,948,430,28,'#FFFFFF')+f'<g transform="translate(95 220) scale(.78)">{mascot()}</g><g transform="translate(520 362) scale(.95)">{word()}</g>'+text('Good Food, Brighter Days.',530,480,23)
b+=rect(1036,208,500,430,28,C['mint'])+f'<g transform="translate(1130 220) scale(.64)">{mascot(micro=True)}</g>'+text('APP SYMBOL',1080,596,16)
b+=text('02 / LIGHT & SINGLE COLOUR',64,691,15)+rect(64,720,710,210,24,C['navy'])+f'<g transform="translate(82 728) scale(.38)">{mascot(mono="#FFFFFF")}</g><g transform="translate(305 790) scale(.8)">{word("#FFFFFF")}</g>'
b+=rect(798,720,738,210,24,'#FFFFFF')+f'<g transform="translate(822 728) scale(.38)">{mascot(mono=C["navy"])}</g><g transform="translate(1040 790) scale(.8)">{word()}</g>'
b+=text('03 / COLOUR & ICON GRAMMAR',64,985,15)
for i,(n,c) in enumerate(C.items()):
 x=64+i*249;b+=rect(x,1010,227,83,16,c)+text(n.upper(),x,1123,16)+text(c,x,1150,15)
for i,(name,d) in enumerate(icons.items()):
 x=80+(i%12)*123;y=1200+(i//12)*100
 b+=f'<g transform="translate({x} {y}) scale(1.5)">{stroke(d,C["green"],1.8)}</g>'+text(name,x-4,y+59,11)
b+=text('VECTOR MASTER 1.1  /  CORAL OCTOPUS + CHEF HAT + LEAF',64,1447,15)
save('preview/takosan-brand-board.svg',svg(b,1600,1480))
# Contact sheet with genuine source variants.
b=rect(0,0,1600,900,0,C['cream'])+text('TAKOSAN / VECTOR POSE LIBRARY',40,45,25)
for i,p in enumerate(['neutral','wave','fridge','leaf','cooking','calendar','shopping','celebrate','thinking','recipe']):
 x=40+i%5*315;y=85+i//5*390;b+=f'<g transform="translate({x} {y}) scale(.55)">{mascot(p)}</g>'+text(p.upper(),x+75,y+300,16)
save('preview/takosan-pose-library.svg',svg(b,1600,900))
print('Source files created',ROOT)
