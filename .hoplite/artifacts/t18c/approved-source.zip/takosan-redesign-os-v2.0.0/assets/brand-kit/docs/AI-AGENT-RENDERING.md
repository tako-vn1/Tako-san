# Takosan rendering contract

Use this kit as the only visual source of truth. Use the supplied SVG for every logo and icon; never ask an image model to typeset TAKOSAN or redraw the mark. Use `mascot/takosan-neutral.svg` as the canonical geometry for vector work and `mascot/takosan-neutral-3d-master.png` only for raster illustration.

## Locked identity

Coral octopus `#FF7B6B`, deep navy eyes/text `#1F2937`, leaf green `#2E7D5B`, warm cream `#FFF8F3`, mint `#DFF4E6`, yellow `#FFC857`. The mascot always has a large round head, short soft curls, two oval navy eyes, small U smile, three-lobed cream toque, and one green leaf. Keep the same head/eye/hat proportions. Change only pose, expression, prop, camera, and background.

## Delivery rules

1. Read `design-tokens/brand-tokens.json` before coding.
2. Reference assets by path; do not copy-paste or approximate the logo.
3. Use `ui-icons/` with `currentColor`, 24×24 viewBox, 1.8px round stroke.
4. Use the light app icon on cream, dark icon on navy, and micro symbol below 32px.
5. Test full lockup at 120px, symbol at 24px, grayscale, dark background, and one-colour print.
6. Keep copy editable. The supplied marketing SVGs are templates, not flattened images.

## Rejection criteria

Reject any output with a different face, missing toque or leaf, realistic suction cups, long tentacles, red/purple/blue mascot, heavy outline, rainbow palette, anime eyes, baked-in incorrect text, watermark, or a replacement wordmark.

## Prompt prefix for raster variants

“Canonical Takosan mascot from the supplied reference: compact kawaii coral octopus chef, large rounded head, short soft curled tentacles, oval deep-navy eyes with tiny cream glints, small U smile, subtle blush, soft cream three-lobed chef toque, one green leaf accent. Preserve exact identity, proportions, colors, and silhouette. Premium matte 3D-flat hybrid, cute but sophisticated, warm diffuse light, clean background, no text.”

## Asset map

- Core logos: `logo/`
- Pose library: `mascot/`
- UI icons: `ui-icons/`
- Platform icons: `app-icons/`
- Campaign templates: `marketing/` and `social/`
- Tokens: `design-tokens/`
- QA boards: `preview/`
