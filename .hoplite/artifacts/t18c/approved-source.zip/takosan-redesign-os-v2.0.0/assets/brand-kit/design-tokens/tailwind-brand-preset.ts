export default {
  "theme": {
    "extend": {
      "colors": {
        "takosan": {
          "coral": "#FF7B6B",
          "green": "#2E7D5B",
          "navy": "#1F2937",
          "cream": "#FFF8F3",
          "mint": "#DFF4E6",
          "yellow": "#FFC857"
        }
      },
      "borderRadius": {
        "sm": "10px",
        "md": "16px",
        "lg": "24px",
        "xl": "32px"
      }
    }
  }
};
