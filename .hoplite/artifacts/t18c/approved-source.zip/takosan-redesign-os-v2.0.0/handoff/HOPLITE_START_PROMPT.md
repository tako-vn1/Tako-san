# Hoplite start prompt

Work on T17 in `frigo-6/Frigo-dev` using the attached `takosan-redesign-os-v2.0.0.zip` as the official design contract.

Read `00_README_FIRST.md`, then follow `01_MASTER_EXECUTION_PROMPT.md` exactly. Start from current remote `main`, record its live SHA, create only `feat/t17-takosan-ui-v2`, audit before editing, then continue implementation through all checkpoint phases. Do not stop at planning.

Do not merge or deploy. Preserve auth/security, Inventory Truth, OCR/AI routing, recipe rollout authority and planning algorithms. PayOS/payment/payment grants must receive zero application change. Unsupported capabilities must show honest unavailable states; never invent data, persistence or success.

Use the supplied assets and 27 screen contracts. Run all regression, responsive, visual and accessibility gates. Push the branch and create `docs/ai/T17_UI_V2_REPORT.md` with evidence and an honest `T17_COMPLETE`, `T17_PARTIAL` or `T17_BLOCKED` status.
