# Hoplite recovery prompt

Resume T17 on the existing branch `feat/t17-takosan-ui-v2` in `frigo-6/Frigo-dev`.

Do not start over, reset history, merge to `main`, or deploy. Read the attached OS kit in its required order, then inspect:

- `docs/ai/T17_UI_V2_AUDIT.md`;
- `docs/ai/T17_UI_V2_REPORT.md` if present;
- the latest `docs/ai/T17_*HANDOFF*.md`;
- branch log/checkpoint commits;
- worktree status and uncommitted diff;
- test output/artifacts already recorded.

Verify the last safe checkpoint, compare completed work to all 27 screen contracts and `QA/definition-of-done.md`, then continue only the missing work. Preserve unrelated changes. Re-run focused tests for inherited code before trusting it. Update the handoff/report after each checkpoint.

All original boundaries still apply: auth/security, Inventory Truth, OCR/AI, recipe authority and Planner algorithms are preserved; PayOS/payment receives zero application change; production remains untouched. Report exact evidence and never call partial work complete.
