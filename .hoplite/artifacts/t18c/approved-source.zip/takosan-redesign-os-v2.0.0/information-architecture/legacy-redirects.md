# Legacy redirect policy

Inventory every legacy route before changing routing. Redirect only when query, fragment, selected week/day, item identity, and return path can be preserved safely.

Expected categories to inspect:

- legacy `/week/*` → equivalent Planner route;
- older inventory path → `/fridge` or `/fridge/:id`;
- generic preference/settings deep links → dedicated target settings route;
- legacy Plus presentation path → `/plus`.

Do not create redirect loops, force auth on public landing, or discard capabilities still available only in legacy Week. Record each source, destination, parameter mapping, test, and temporary compatibility exception in the T17 report.
