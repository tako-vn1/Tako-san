# Account and Settings architecture

`/me` is an account hub, not a generic settings dump.

- `/me/preferences`: food taste, restrictions, dislikes, spice, serving defaults.
- `/me/household`: household overview, members, sharing, shared inventory; unsupported actions show honest state.
- `/notifications`: actual inbox only.
- `/settings/planning`: defaults for future plans. It is not the new-plan flow.
- `/settings/notifications`: delivery preferences and quiet hours, reflecting real channel availability.
- `/settings/app`: PWA, offline, language, cache, storage, version.
- `/settings/privacy`: AI/data explanations, permissions, export/delete only when supported.
- `/plus`: Takosan Plus presentation around existing entitlement and payment contracts.

`WeekSetup` creates a plan. It must not remain the settings surface.
