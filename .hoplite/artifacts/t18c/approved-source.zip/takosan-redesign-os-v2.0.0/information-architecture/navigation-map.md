# Navigation map

Primary authenticated destinations are Home, Fridge, Recipes, Planner, and Profile. Scan is a contextual primary action and may be a central mobile action without becoming a sixth information-architecture root. Shopping is reachable from Planner and direct saved state. Notifications are reached from the global notification control and Profile.

Mobile uses bottom navigation. Tablet uses a navigation rail. Desktop uses a sidebar. Active state uses `aria-current="page"` and `SharedIndicator`. Immersive auth, onboarding, scan, and cooking hide primary navigation.

Unauthenticated `/` and `/landing` never force login. Guest trial stays available under the current safe guest contract. Authenticated entry routing must follow server session and onboarding authority, not local guesses.
