# Current-to-target decisions

| Current overlap/debt | Target authority |
| --- | --- |
| Landing/auth/onboarding each re-check identity | Server-authoritative funnel with no duplicate login gate |
| Phone-width pages on desktop | AppShell V2 responsive canvas |
| Local buttons/cards/dialogs | Shared design-system primitives |
| Week and Planner as competing products | Planner canonical; Week compatibility only |
| Profile mixed with all settings | Profile Hub plus dedicated settings routes |
| Food preferences routed to generic settings | Dedicated Food Preferences screen |
| Notification inbox includes toggles | Inbox and Preferences separated |
| WeekSetup used as settings | New-plan flow only |
| Visible Frigo presentation | Takosan naming/assets; internal compatibility retained |
| Unsupported actions appear successful | Honest unavailable/not-configured state |
