# 19 — Profile Hub

- **Purpose:** Central account identity and navigation hub, not a mixed settings form.
- **Route:** `/me`.
- **Data source:** Current authenticated identity, entitlement, household summary, preference completion and notification counts.
- **Primary action:** Contextual account destination; no forced global CTA.
- **Secondary actions:** Open Plus, household, food preferences, planning settings, notifications and app settings.
- **Hierarchy:** Identity → membership/Plus → household → food preferences → planning → notifications/settings.
- **Components:** Page, Avatar, Surface, List/ListRow, StatusBadge, Section.
- **Responsive:** Mobile grouped hub; tablet/desktop identity summary plus grouped navigation columns.
- **Motion:** Standard page and navigation indicator only.
- **States:** Profile loading/error, missing optional avatar, entitlement unknown, partial summaries.
- **Accessibility:** Navigation rows are links, not divs; avatar alt appropriate; unread count has text.
- **Preserve:** Session identity and entitlement truth; do not use board example user data.
- **Acceptance:** Food preferences no longer link to generic settings; Profile contains navigation summaries rather than duplicate editable forms.
- **Reference:** Board 3, screen 19.
