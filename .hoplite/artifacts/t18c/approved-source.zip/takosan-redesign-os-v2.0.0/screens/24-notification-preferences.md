# 24 — Notification Preferences

- **Purpose:** Configure only real notification channels/categories and quiet hours.
- **Route:** `/settings/notifications`.
- **Data source:** Existing notification settings and infrastructure availability.
- **Primary action:** Save if the contract is form-based; otherwise real switches may update immediately.
- **Secondary actions:** Configure permissions through supported browser/app flow.
- **Hierarchy:** Channel availability → push/email → category preferences → quiet hours → status/help.
- **Components:** Switch, Checkbox, time fields, StatusBadge, Unavailable state, StickyActions.
- **Responsive:** Mobile grouped form; tablet/desktop channels and categories in readable columns.
- **Motion:** Switch feedback only after accepted intent; rollback visible on error.
- **States:** Permission denied, channel not configured, unsupported email/push, saving/error/offline.
- **Accessibility:** `role=switch`, labels/descriptions, time-zone context, status not color-only.
- **Preserve:** Real permission/delivery capability; never pretend push/email is active.
- **Acceptance:** Unsupported channels are clearly unavailable; inbox and preferences remain separate routes.
- **Reference:** Board 3, screen 24.
