# 15 — Shopping List

- **Purpose:** Turn real plan/inventory gaps into a usable grouped shopping workflow.
- **Route:** `/shopping`.
- **Data source:** Existing shopping list, categories, checked state and cost estimates.
- **Primary action:** Contextual list action such as share, when currently supported.
- **Secondary actions:** Check/uncheck, edit/remove, filter checked/remaining, open source plan.
- **Hierarchy:** Summary/filter → remaining groups → checked group → cost summary → share/action.
- **Components:** Tabs/SegmentedControl, Checkbox, grouped ListRows, StatusBadge, StickyActions.
- **Responsive:** Mobile grouped list; tablet/desktop list with summary/sidebar. Do not use generic SettingsRow.
- **Motion:** Layout animation on check/group move using stable identity.
- **States:** Empty, all checked, loading, cost unavailable/estimated, write failure, offline/stale.
- **Accessibility:** Checkbox labels include item/quantity; checked styling is not color-only; share result announced.
- **Preserve:** Existing list authority, units, cost semantics and inventory/planner relationship.
- **Acceptance:** Estimates are labelled, checks persist only through real contract, and completed items remain recoverable.
- **Reference:** Board 2, screen 15.
