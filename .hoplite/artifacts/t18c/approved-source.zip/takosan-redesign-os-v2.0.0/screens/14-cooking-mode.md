# 14 — Cooking Mode

- **Purpose:** One-hand, distraction-reduced execution of one recipe step at a time.
- **Route:** `/cook/:slug`.
- **Data source:** Existing recipe steps, timers and any persisted cooking state already supported.
- **Primary action:** Next step / complete.
- **Secondary actions:** Previous, timer controls, close with safe confirmation if needed.
- **Hierarchy:** Exit/title → progress → step image/instruction → timer/context → previous/next.
- **Components:** Fullscreen Page, Progress, IconButton, timer feature, StickyActions.
- **Responsive:** No primary app navigation. Mobile one active step; tablet/desktop may show adjacent context without shrinking main instruction.
- **Motion:** Directional step transition; timer does not depend on animation frames.
- **States:** No steps, timer running/paused/completed, background/resume, offline, recipe unavailable.
- **Accessibility:** Large type, 44px+ controls, live timer announcement only at useful milestones, screen-wake feature only if existing and disclosed.
- **Preserve:** Authoritative recipe steps and any existing cooking-state behavior.
- **Acceptance:** Previous/next direction is consistent; timers remain correct across visibility changes; bottom nav is absent.
- **Reference:** Board 2, screen 14.
