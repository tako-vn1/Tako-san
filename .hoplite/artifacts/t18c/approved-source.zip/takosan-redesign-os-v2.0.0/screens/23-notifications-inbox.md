# 23 — Notifications Inbox

- **Purpose:** Display actual notifications and read state only.
- **Route:** `/notifications`.
- **Data source:** Existing notification inbox/read contract.
- **Primary action:** Open the most relevant notification destination; no preference toggles.
- **Secondary actions:** Mark read/all read if supported; filter real categories.
- **Hierarchy:** Header/unread summary → filters → chronological notification groups.
- **Components:** Tabs/FilterChip, notification feature row, Badge, Empty/Error state.
- **Responsive:** Mobile chronological list; tablet/desktop wider list with optional filter rail.
- **Motion:** New/read-state layout feedback; no decorative entrance on every refresh.
- **States:** Loading, empty, unread/filtered empty, pagination error, stale/offline.
- **Accessibility:** Read/unread stated in text/ARIA; timestamps understandable; destination links descriptive.
- **Preserve:** Existing notification truth and read mutations.
- **Acceptance:** Inbox contains no delivery preference switches; fake promotional notifications are not created.
- **Reference:** Board 3, screen 23.
