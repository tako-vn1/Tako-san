# 05 — Onboarding: Food Preferences

- **Purpose:** Capture cuisine interests, restrictions, and dislikes with clear hierarchy.
- **Route:** `/onboarding/preferences`.
- **Data source:** Existing preference options and onboarding draft/server contract.
- **Primary action:** Continue.
- **Secondary action:** Back; optional add dislike only if supported.
- **Hierarchy:** Progress 2/3 → cuisine multi-select → dietary restrictions → dislikes → continue.
- **Components:** Chip/Checkbox, Searchable choice if required, TextField only for a real supported custom value, BottomCTA.
- **Responsive:** Single flow mobile; grouped columns on wider screens without changing form order.
- **Motion:** Directional step transition; chip selection uses shared indicator/color feedback.
- **States:** Loading option catalog, saved selection, validation, unsupported custom input, offline.
- **Accessibility:** Fieldsets/legends, multi-select semantics, clear “none” behavior, no color-only selection.
- **Preserve:** Existing preference vocabulary and persistence; do not invent restriction taxonomies.
- **Acceptance:** “None” conflicts are resolved visibly; values round-trip to current server representation.
- **Reference:** Board 1, screen 5.
