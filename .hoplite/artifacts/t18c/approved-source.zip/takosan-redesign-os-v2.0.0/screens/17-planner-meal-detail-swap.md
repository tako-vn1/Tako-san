# 17 — Planner Meal Detail / Swap

- **Purpose:** Explain one planned meal and safely choose an alternative.
- **Route:** `/planner/:planId/meal/:slotId`.
- **Data source:** Existing slot, recommendation reasons, requirements, coverage and alternatives.
- **Primary action:** Confirm a selected swap through the current mutation contract.
- **Secondary actions:** View recipe, open alternatives, cancel/back.
- **Hierarchy:** Meal facts → inventory coverage → why recommended → requirements → alternative entry.
- **Components:** Page, Progress/coverage, StatusBadge, recipe cards, shared BottomSheet, Alert/Error state.
- **Responsive:** Mobile detail with swap sheet; tablet/desktop detail plus sheet/dialog/side panel from the same state.
- **Motion:** Shared BottomSheet; selected alternative continuity; layout animation after confirmed swap.
- **States:** Loading, no alternatives, calculating, conflict/stale plan, mutation error, offline.
- **Accessibility:** Sheet focus trap/return; alternatives form a labelled selection set; reasons readable in text.
- **Preserve:** Swap algorithm, plan versioning, coverage semantics and server validation.
- **Acceptance:** No optimistic fake success; swap rollback/error is visible; plan/slot identity is retained.
- **Reference:** Board 2, screen 17.
