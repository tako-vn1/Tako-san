# 22 — Planning Settings

- **Purpose:** Edit defaults for future planning, separate from creating a new plan.
- **Route:** `/settings/planning`.
- **Data source:** Existing planning preferences, budget, shopping frequency, meal slots, priorities and serving defaults.
- **Primary action:** Save settings.
- **Secondary actions:** Restore current/server defaults only if supported; back.
- **Hierarchy:** Budget → shopping frequency → meal slots → priorities → servings → save.
- **Components:** NumberField, SelectField, Checkbox, Number controls, Section, StickyActions.
- **Responsive:** Mobile grouped form; tablet/desktop section nav or two-column form.
- **Motion:** Local selection feedback only.
- **States:** Loading, unsupported field, saving, validation, conflict, offline.
- **Accessibility:** Currency/unit descriptions, grouped checkboxes, error summary, dirty-state handling.
- **Preserve:** Existing settings fields and planning algorithm; WeekSetup remains the new-plan flow.
- **Acceptance:** No settings control silently invokes plan generation; unsupported defaults are not persisted client-only.
- **Reference:** Board 3, screen 22.
