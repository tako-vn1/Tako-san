# 09 — Scan Review

- **Purpose:** Let the user verify and edit AI suggestions before inventory mutation.
- **Route:** `/scan/:scanId/review` or safe current equivalent.
- **Data source:** Existing scan result, confidence when provided, units and inventory write contract.
- **Primary action:** Confirm/save reviewed ingredients.
- **Secondary actions:** Edit, remove, add another item, retry scan when supported.
- **Hierarchy:** Result context → review notice → item list → add item → confirmation.
- **Components:** List/ListRow, Thumbnail, NumberField, SelectField, StatusBadge, BottomSheet/Dialog editor, BottomCTA.
- **Responsive:** Mobile editable list; tablet/desktop review workspace with preview/context and results.
- **Motion:** Stable-key insertion/removal/layout; no confidence animation.
- **States:** Processing continuation, partial recognition, low confidence, empty result, save conflict, write failure.
- **Accessibility:** Every edit/remove action names its ingredient; confidence has text; error focus and status announcements.
- **Preserve:** “AI suggests — user confirms”, inventory writer/reconciliation/fencing, unit truth and privacy.
- **Acceptance:** No item is saved without explicit confirmation; partial failures are itemized; duplicate confirm is prevented.
- **Reference:** Board 1, screen 9.
