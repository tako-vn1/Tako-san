# 02 — Sign in / Register

- **Purpose:** Authenticate or create an account in one coherent shell.
- **Route:** `/auth` with stable state/query handling for login, register, and forgot-password.
- **Data source:** Existing auth endpoints, Turnstile, Google GSI/client ID, session and server errors.
- **Primary action:** Current form submit.
- **Secondary actions:** Switch mode, Google auth, forgot password, back.
- **Hierarchy:** AuthShell/brand → mode selection → fields → submit → separator → Google → legal links.
- **Components:** AuthShell, LoginForm, RegisterForm, GoogleAuth, ForgotPassword, TextField, Button, Tabs/SegmentedControl, ErrorState.
- **Responsive:** Compact mobile fullscreen; centered tablet; compact or restrained split desktop. Auth owns its width, not AppShell navigation.
- **Motion:** Presence transition between modes without clearing intentional user input.
- **States:** Submitting, field/server error, Turnstile failure, Google unavailable, rate limit, offline. Never show success before server confirmation.
- **Accessibility:** Real labels, password reveal accessible name, error summary/focus, autocomplete, live submit status.
- **Preserve:** Security, cookies, CSRF, session rotation, T16 funnel, Turnstile, GSI contract and exact error semantics.
- **Acceptance:** Monolithic page is decomposed; no duplicate login gate; keyboard-only flow works; auth tests remain green.
- **Reference:** Board 1, screen 2.
