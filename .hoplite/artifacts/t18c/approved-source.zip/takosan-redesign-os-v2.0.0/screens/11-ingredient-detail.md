# 11 — Ingredient Detail / Edit

- **Purpose:** Inspect and edit one ingredient without weakening inventory truth.
- **Route:** `/fridge/:id` with current identifier contract.
- **Data source:** Existing inventory item, units, storage, expiry provenance/freshness and write contract.
- **Primary action:** Save update.
- **Secondary actions:** Delete with confirmation, back/cancel, image change only if real.
- **Hierarchy:** Identity/image → quantity/unit → storage → expiry with provenance → notes/freshness → actions.
- **Components:** Page or responsive editor sheet, NumberField, SelectField, date/provenance controls, Textarea, StatusBadge, StickyActions, AlertDialog.
- **Responsive:** Mobile full editor; tablet/desktop split identity and form or side panel.
- **Motion:** Editor/sheet entrance; restrained save feedback.
- **States:** Loading, not found, stale version/conflict, validation error, saving, delete error, offline.
- **Accessibility:** Labels/descriptions for expiry provenance, semantic delete confirmation, error summary.
- **Preserve:** Unknown expiry must stay unknown; estimated remains visibly estimated; known remains known; no default date substitution.
- **Acceptance:** Round-trip preserves provenance and units; cancel loses no data silently; concurrent edits surface honestly.
- **Reference:** Board 2, screen 11.
