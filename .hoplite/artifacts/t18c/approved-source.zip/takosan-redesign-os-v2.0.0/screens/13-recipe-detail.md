# 13 — Recipe Detail

- **Purpose:** Explain a recipe, inventory coverage and method, then start cooking.
- **Route:** `/recipes/:slug` or current stable recipe identifier.
- **Data source:** Existing authoritative recipe detail, availability, nutrition and rollout state.
- **Primary action:** Start cooking when steps exist and access permits.
- **Secondary actions:** Favorite/share if real, view missing items/add to shopping, back.
- **Hierarchy:** Hero → title/facts → inventory availability → ingredients → instructions → nutrition → CTA.
- **Components:** Page, image hero, Tabs when content warrants, StatusBadge, ingredient list, BottomCTA.
- **Responsive:** Image-first mobile; desktop hero/detail columns with readable method width.
- **Motion:** Safe card-to-detail continuity or standard route transition; never delay content.
- **States:** Loading, not found, rollout unavailable, partial availability failure, missing nutrition, offline cached.
- **Accessibility:** Heading, image alt, structured ingredient quantities, text status for available/missing.
- **Preserve:** Recipe authority and inventory-grounded coverage; do not infer nutrition or missing data.
- **Acceptance:** Start-cooking availability is truthful; deep link and back behavior are stable; unknown fields are omitted or labelled—not fabricated.
- **Reference:** Board 2, screen 13.
