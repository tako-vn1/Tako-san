# 27 — Takosan Plus

- **Purpose:** Present current premium entitlement and plans under Takosan branding.
- **Route:** `/plus` plus safe redirect from any legacy visible Plus path.
- **Data source:** Existing product/price/entitlement/payment initiation contracts.
- **Primary action:** Existing upgrade/payment initiation action with unchanged behavior.
- **Secondary actions:** Restore/check purchase or manage entitlement only if already supported.
- **Hierarchy:** Takosan Plus value → truthful benefits → current entitlement → real plans/prices → primary action → payment/legal support.
- **Components:** Page, brand assets, Surface, StatusBadge, Button, real plan selector.
- **Responsive:** Mobile focused offer; tablet/desktop comparison/value layout without excessive cards.
- **Motion:** Restrained hero entrance and selection indicator; no manipulative countdown or celebratory loop.
- **States:** Current subscriber, loading entitlement, price unavailable, payment initiation error, region/unavailable.
- **Accessibility:** Plan names/prices/periods explicit, savings claims mathematically grounded, no color-only selection.
- **Preserve:** **Zero PayOS/payment/payment-grant application change.** Preserve entitlement truth and verification.
- **Acceptance:** No visible “Frigo Plus” or hardcoded emerald presentation remains; real price source is used; payment code diff is zero.
- **Reference:** Board 3, screen 27.
