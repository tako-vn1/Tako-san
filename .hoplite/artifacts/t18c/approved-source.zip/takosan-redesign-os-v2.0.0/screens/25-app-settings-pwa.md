# 25 — App Settings / PWA

- **Purpose:** Contain application/runtime settings only.
- **Route:** `/settings/app` (with `/settings` as hub/redirect according to router design).
- **Data source:** Existing PWA installability, offline support, language, cache/storage and build version.
- **Primary action:** Contextual real action such as install or clear cache.
- **Secondary actions:** Language/offline settings only if implemented.
- **Hierarchy:** PWA install/status → offline → language → cache/storage → version.
- **Components:** SettingsRow, Switch only for real toggles, StatusBadge, AlertDialog for cache clearing.
- **Responsive:** Mobile grouped list; tablet/desktop settings navigation + content.
- **Motion:** Minimal; system status changes only.
- **States:** Not installable/already installed, offline unsupported, storage estimate unavailable, clear failure.
- **Accessibility:** Status text, semantic buttons, consequences explained before destructive cache actions.
- **Preserve:** Existing service worker/PWA/cache behavior; do not add a fake offline toggle.
- **Acceptance:** Version is sourced from real build metadata; cache action reports actual outcome.
- **Reference:** Board 3, screen 25.
