# 18 — Planner Shopping Optimization

- **Purpose:** Explain the shopping result, budget fit, priority purchases and inventory utilization.
- **Route:** `/planner/:planId/shopping`.
- **Data source:** Existing optimization result, estimated costs, priorities, budget and utilization.
- **Primary action:** Save/apply optimization only when a real contract exists; otherwise continue to real shopping list.
- **Secondary actions:** Adjust supported budget input, inspect items, return to plan.
- **Hierarchy:** Budget → estimate/fit → priority list → utilization → optimization explanation → action.
- **Components:** Page, Progress, NumberField when supported, prioritized List, StatusBadge, BottomCTA.
- **Responsive:** Mobile linear summary/list; tablet/desktop metrics beside prioritized list.
- **Motion:** Recalculation uses localized progress and list layout; do not animate numbers misleadingly.
- **States:** Calculating, over budget, no purchases needed, estimate unavailable, error/stale/offline.
- **Accessibility:** Currency and percentages announced with context; priority not color-only.
- **Preserve:** Planning, budget and optimization algorithms; estimated values remain labelled estimates.
- **Acceptance:** UI does not recompute an alternative client algorithm; plan changes invalidate or refresh results honestly.
- **Reference:** Board 2, screen 18.
