# 10 — Inventory

- **Purpose:** A high-density workspace for finding and safely updating fridge truth.
- **Route:** `/fridge`.
- **Data source:** Existing inventory query/store, reconciliation state and server writer truth.
- **Primary action:** Add ingredient via one FAB.
- **Secondary actions:** Scan fridge, search/filter, open detail, reconcile, quick quantity update.
- **Hierarchy:** Page header → search/filter → use-soon section → all inventory → reconciliation/status actions.
- **Components:** SearchField, FilterChip, Inventory feature row, StatusBadge, Number controls, FAB, BottomSheet.
- **Responsive:** Mobile single list; tablet filters+list; desktop workspace with filters/summary and content—not card-per-item.
- **Motion:** Stable-key add/remove/reorder layout; pending writes do not reorder until safe.
- **States:** Loading, empty, filter-empty, partial refresh failure, pending/conflict/retry, offline/stale.
- **Accessibility:** Quantity controls name item/unit; table/list semantics appropriate to layout; status not color-only.
- **Preserve:** `UNKNOWN ≠ ESTIMATED ≠ KNOWN`, reconciliation, fencing, optimistic concurrency and server identity.
- **Acceptance:** No fabricated expiry; quick update rollback is visible on failure; reconciliation remains reachable; no duplicate local business-state clone.
- **Reference:** Board 2, screen 10.
