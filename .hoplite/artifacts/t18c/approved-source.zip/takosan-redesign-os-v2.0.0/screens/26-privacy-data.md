# 26 — Privacy & Data

- **Purpose:** Explain data/AI use and expose only supported permission/export/delete actions.
- **Route:** `/settings/privacy`.
- **Data source:** Current privacy copy/contracts, browser permissions and real account APIs.
- **Primary action:** Context-dependent; destructive delete only if fully supported.
- **Secondary actions:** Permission management, export request when real, open policies.
- **Hierarchy:** Privacy summary → data collected/use → AI usage → permissions → export → delete account.
- **Components:** Page, Section, SettingsRows, StatusBadge, AlertDialog, honest Unavailable states.
- **Responsive:** Mobile stacked sections; tablet/desktop navigation + readable policy column.
- **Motion:** None beyond dialogs/page transition.
- **States:** Permission unavailable/denied, export unsupported/pending, deletion unsupported/error.
- **Accessibility:** Plain language, external links identified, destructive consequences and focus behavior.
- **Preserve:** Current policy/security/account contracts; no fake export file or deletion success.
- **Acceptance:** Every action maps to a real capability or is visibly unavailable; PayOS/payment data behavior is untouched.
- **Reference:** Board 3, screen 26.
