# 16 — Planner Overview

- **Purpose:** Canonical weekly meal-planning surface combining plan, utilization, budget and days.
- **Route:** `/planner` and `/planner/:planId` as existing architecture permits.
- **Data source:** Existing plan authority, meals, inventory utilization, budget and shopping calculations.
- **Primary action:** Create plan when absent; otherwise open the next/highest-priority meal.
- **Secondary actions:** Switch week, add meal through real flow, open shopping optimization, open meal detail.
- **Hierarchy:** Week switch → summary metrics → day navigation → daily meals → shopping/budget action.
- **Components:** Page, Tabs/Segmented day control, Progress, meal feature rows/cards, StatusBadge, Buttons.
- **Responsive:** Mobile day sections; tablet summary+days; desktop overview/detail-capable canvas.
- **Motion:** Week/day changes animate layout without hiding stale/loading truth.
- **States:** No plan, generating, ready, partial data, stale/conflict, generation error, offline.
- **Accessibility:** Week controls named, day/meal hierarchy, metrics include text, keyboard navigation.
- **Preserve:** Planning algorithm, budget math, meal identity and server authority.
- **Acceptance:** Planner is the visible canonical UX; every surviving Week capability has an equivalent entry or documented compatibility route.
- **Reference:** Board 2, screen 16.
