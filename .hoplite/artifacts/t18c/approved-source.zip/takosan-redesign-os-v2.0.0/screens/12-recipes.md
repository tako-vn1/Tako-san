# 12 — Recipes

- **Purpose:** Discovery-oriented recipe browsing grounded in current catalog authority.
- **Route:** `/recipes`.
- **Data source:** Existing recipe catalog, rollout authority, personalization, availability and filters.
- **Primary action:** Open a recommended or selected recipe.
- **Secondary actions:** Search, filter, favorite if supported, browse sections.
- **Hierarchy:** Search/filter → recommended → available-now → popular/other catalog sections.
- **Components:** SearchField, FilterChip, image-first RecipeCard, SectionHeader, Skeleton/EmptyState.
- **Responsive:** Mobile horizontal feature + grids; tablet/desktop responsive discovery grid, not inventory-style rows.
- **Motion:** Card interactions and safe continuity to detail; list changes restrained.
- **States:** Loading, empty catalog, no filter matches, partial recommendation failure, rollout unavailable.
- **Accessibility:** Meaningful image alt, recipe facts in text, favorite accessible state, headings for sections.
- **Preserve:** Catalog authority, Shadow/Canary behavior, grounded availability and current favorite contract.
- **Acceptance:** UI never promotes shadow-only data as authoritative; filter/search use existing truth; missing images have consistent fallback.
- **Reference:** Board 2, screen 12.
