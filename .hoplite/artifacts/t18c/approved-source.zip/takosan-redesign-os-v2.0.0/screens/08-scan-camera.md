# 08 — Scan Camera

- **Purpose:** Capture fridge, food, or receipt imagery while maintaining privacy and context.
- **Route:** `/scan`.
- **Data source:** Existing camera/gallery permissions, scan modes, upload/session and OCR/AI flow.
- **Primary action:** Capture/select image.
- **Secondary actions:** Mode switch, gallery, camera flip/flash if truly supported, close.
- **Hierarchy:** Immersive preview → mode segmented control → viewfinder/instruction → capture controls → privacy/status.
- **Components:** Fullscreen surface, SegmentedControl, IconButton, Progress, permission ErrorState.
- **Responsive:** Fullscreen mobile/tablet; desktop camera workspace without phone emulation.
- **Motion:** Camera → processing retains captured thumbnail/context; review transition is directional/crossfade.
- **States:** Permission prompt/denied, no camera, uploading, processing, OCR failure, retry, offline.
- **Accessibility:** Text alternatives for controls, status announcements, non-camera gallery path, visible close.
- **Preserve:** Current private image lifetime, auth/session, OCR processing, provider routing and safety limits.
- **Acceptance:** Three supported modes are truthful; private images are not newly persisted; interruption/retry does not duplicate jobs.
- **Reference:** Board 1, screen 8.
