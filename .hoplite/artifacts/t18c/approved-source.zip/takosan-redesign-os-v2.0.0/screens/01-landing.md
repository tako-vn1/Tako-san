# 01 — Landing

- **Purpose:** Explain Takosan's value and let a visitor try safely or enter auth without a forced gate.
- **Route:** `/` and/or `/landing` according to server-aware entry routing.
- **Data source:** Public/static product content and existing guest/session capability; no fake personalized data.
- **Primary action:** `Dùng thử ngay (Khách)` when the real guest contract allows it.
- **Secondary action:** Sign in / create account.
- **Hierarchy:** Takosan mark → one value proposition → product visual/mascot → primary CTA → auth CTA → concise trust/support copy.
- **Components:** Page, Surface, Button, LinkButton, logo/mascot assets.
- **Responsive:** Mobile hero stack; tablet balanced two-region layout; desktop split hero with readable copy, not a centered phone.
- **Motion:** One gentle hero/mascot entrance on first mount; no loops.
- **States:** If guest mode is unavailable, state that honestly and promote auth; never dead-link.
- **Accessibility:** Descriptive heading, correct link/button semantics, image alt or decorative empty alt, logical focus order.
- **Preserve:** T16 public landing and guest/auth funnel behavior.
- **Acceptance:** Landing renders without authentication, exposes no duplicate CTAs, has no horizontal overflow, and routes using current auth/session truth.
- **Reference:** Board 1, screen 1.
