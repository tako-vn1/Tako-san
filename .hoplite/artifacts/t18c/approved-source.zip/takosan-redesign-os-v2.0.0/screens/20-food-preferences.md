# 20 — Food Preferences

- **Purpose:** Dedicated editor for cuisines, restrictions, dislikes, spice and serving defaults.
- **Route:** `/me/preferences`.
- **Data source:** Existing preference catalog/profile contract.
- **Primary action:** Save real changes.
- **Secondary actions:** Cancel/back and supported custom entries.
- **Hierarchy:** Cuisines → restrictions → dislikes → spice → servings → save.
- **Components:** Chip/Checkbox, Radio/SegmentedControl, NumberField, TextField only if supported, StickyActions.
- **Responsive:** Mobile grouped editor; tablet/desktop sections in readable columns.
- **Motion:** Selection micro-feedback; save status restrained.
- **States:** Loading, unchanged, dirty, saving, validation/server error, conflict, offline.
- **Accessibility:** Fieldsets/legends, selection beyond color, dirty-exit protection when warranted.
- **Preserve:** Existing preference vocabulary, mapping and server truth.
- **Acceptance:** Values round-trip without lossy conversion; unsupported fields are omitted or explicitly unavailable, never stored locally as fake truth.
- **Reference:** Board 3, screen 20.
