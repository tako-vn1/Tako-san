# 06 — Onboarding: Planning Goals

- **Purpose:** Set high-level planning priorities and finish onboarding.
- **Route:** `/onboarding/goals`.
- **Data source:** Existing supported goal fields and server onboarding authority.
- **Primary action:** Finish and follow server-authoritative redirect to Home.
- **Secondary action:** Back.
- **Hierarchy:** Progress 3/3 → goal choice cards → explanation → finish.
- **Components:** ChoiceCard/Checkbox, Progress, BottomCTA.
- **Responsive:** Two-column cards when space permits; one column under zoom/long copy.
- **Motion:** Directional step; one restrained success transition after confirmed completion.
- **States:** Saving, server validation, conflict, retry, offline; no premature completion.
- **Accessibility:** Multi-select instructions, descriptions bound to controls, focus moves to errors or destination.
- **Preserve:** Current onboarding completion and server redirect truth.
- **Acceptance:** Completing once cannot create a duplicate onboarding loop; Home is reached only after confirmed server state.
- **Reference:** Board 1, screen 6.
