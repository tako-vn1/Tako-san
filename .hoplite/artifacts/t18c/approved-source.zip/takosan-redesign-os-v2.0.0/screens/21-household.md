# 21 — Household & Sharing

- **Purpose:** Show real household status and available collaboration capability.
- **Route:** `/me/household`.
- **Data source:** Existing household/member/share APIs if present; otherwise current capability/status only.
- **Primary action:** Invite/share only when a real secure contract exists.
- **Secondary actions:** Inspect member/shared inventory, manage allowed actions.
- **Hierarchy:** Household summary → invitation/share status → members → shared inventory summary → limitations.
- **Components:** Page, Avatar, ListRows, StatusBadge, Button, Dialog for real invite, Empty/Unavailable state.
- **Responsive:** Mobile sections; tablet/desktop summary and members/shared inventory columns.
- **Motion:** List insertion/removal only after server confirmation.
- **States:** No household, loading, invite unavailable, pending invitation, error, permission denied.
- **Accessibility:** Member role/status text, QR has a text/share alternative only when real, actions name member.
- **Preserve:** Existing authorization and household truth; no fake members, invite codes or shared counts.
- **Acceptance:** Unsupported backend produces an honest explanatory surface, not demo data or successful invite toast.
- **Reference:** Board 3, screen 21.
