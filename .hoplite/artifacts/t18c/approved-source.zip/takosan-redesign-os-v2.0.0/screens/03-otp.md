# 03 — OTP Verification

- **Purpose:** Verify the email using the real delivery state.
- **Route:** `/auth/verify` while preserving existing verification parameters safely.
- **Data source:** Existing OTP request/verify/resend contract and server time/expiry truth.
- **Primary action:** Verify six-digit code (automatic only if existing behavior safely supports it).
- **Secondary actions:** Resend when allowed; return/change email through supported flow.
- **Hierarchy:** Title → masked/confirmed email → delivery explanation → six-digit input → expiry → resend → errors.
- **Components:** Page, TextField or accessible OTP group, Progress/Spinner, Button, ErrorState.
- **Responsive:** Compact centered surface at all widths; keyboard-safe on mobile.
- **Motion:** Short auth-state transition; invalid code feedback must not use disruptive shaking.
- **States:** Sent, sending, expired, cooldown, invalid, rate-limited, delivery unavailable, offline.
- **Accessibility:** One accessible field or well-labelled digit group with paste support; countdown is not announced every second.
- **Preserve:** Honest OTP delivery and security/rate-limit semantics.
- **Acceptance:** Exactly six digits supported, paste/backspace works, resend honors server cooldown, and no fabricated “email sent” state appears.
- **Reference:** Board 1, screen 3.
