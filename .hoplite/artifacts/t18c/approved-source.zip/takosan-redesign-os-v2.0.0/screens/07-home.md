# 07 — Home

- **Purpose:** A decision surface answering “What should I cook today?” rather than a dashboard where every widget competes.
- **Route:** Authenticated Home route (`/` if current router uses it).
- **Data source:** Existing profile/session, grounded recipe suggestions, urgent inventory, current plan, and recommendation sources.
- **Primary action:** Choose/start today's recommended cooking decision.
- **Secondary actions:** View urgent fridge items, open plan, scan/add, view recommendations.
- **Hierarchy:** Greeting → today decision → urgent items → weekly plan → quick actions → recommendations.
- **Components:** Page, PageHeader, Section, SectionHeader, recipe feature card, InventoryRow, Buttons, state boundaries.
- **Responsive:** One decision flow mobile; main/secondary columns tablet; desktop wide canvas with primary decision dominant.
- **Motion:** Sections enter once on first meaningful load; never reanimate on query refresh.
- **States:** Independent loading/error/empty boundaries; keep trustworthy sections if another fails.
- **Accessibility:** Heading hierarchy, descriptive action labels, notification accessible name, content order matches visual order.
- **Preserve:** All live data and Inventory Truth; no invented greeting identity or suggestions.
- **Acceptance:** One clear primary action per region; no equal-weight card grid; partial API failure does not blank the entire page.
- **Reference:** Board 1, screen 7.
