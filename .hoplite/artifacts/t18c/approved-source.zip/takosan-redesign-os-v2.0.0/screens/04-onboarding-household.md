# 04 — Onboarding: Household

- **Purpose:** Capture serving/household context after authentication without asking the user to log in again.
- **Route:** `/onboarding/household` or server-compatible onboarding step.
- **Data source:** Existing onboarding draft/server authority.
- **Primary action:** Continue after a valid choice.
- **Secondary action:** Back when safe.
- **Hierarchy:** Progress 1/3 → question/explanation → large household choice cards → continue.
- **Components:** Page, Progress, RadioCard/ChoiceCard, BottomCTA.
- **Responsive:** 2×2 mobile choice grid when labels fit; wider centered grid on tablet/desktop.
- **Motion:** Forward/back directional step transition.
- **States:** Restoring selection, saving, validation error, server conflict/offline.
- **Accessibility:** Radio-group semantics, selected state beyond color, touch targets, progress label.
- **Preserve:** Preference-only onboarding and server-completion truth.
- **Acceptance:** No auth form appears; saved/back behavior follows current contract; duplicate submission is prevented.
- **Reference:** Board 1, screen 4.
