# Takosan Redesign OS v2.0.0

This archive is the frozen design and engineering contract for **T17 — Takosan UI V2 Full Product Redesign** in `frigo-6/Frigo-dev`.

It is intentionally split into small, addressable specifications. The three visual boards communicate intent; the Markdown and JSON files define the actual rules. Existing application truth always wins over a mockup.

## Required reading order

1. `02_NON_NEGOTIABLE_RULES.md`
2. `03_REPO_BASELINE.md`
3. `01_MASTER_EXECUTION_PROMPT.md`
4. `design-system/`, `motion/`, `layout/`
5. `information-architecture/`
6. Every relevant file in `screens/`
7. `engineering/` and `QA/`

Do not begin code changes before completing the audit required by the master prompt. Do not stop after the audit.

## Sources of truth, in priority order

1. Security, domain truth, current server contracts, and immutable rules in this kit.
2. Semantic design tokens and shared primitives in this kit.
3. Per-screen contracts.
4. Responsive, motion, accessibility, and state contracts.
5. The three visual boards.

The boards are not pixel-perfect backend specifications. Never infer fake data, fake persistence, a fabricated date, or a missing API from a picture.

## Included assets

- `assets/brand-kit/`: canonical Takosan logos, mascot poses, icons, app icons, marketing assets, source tokens, and rendering contract.
- `references/board-01-entry-home-scan.png`
- `references/board-02-food-planner.png`
- `references/board-03-account-settings.png`
- `assets/ASSET_MANIFEST.json`: stable semantic asset keys.

Use supplied SVGs by path. Do not crop marks from boards, redraw the logo, replace the wordmark, or ask an image model to recreate brand assets.

## Execution outcome

The expected outcome is a pushed branch named `feat/t17-takosan-ui-v2`, an unmodified `main`, no deployment, a clean worktree, passing repository gates, isolated T17 visual coverage, and `docs/ai/T17_UI_V2_REPORT.md` with an honest status: `T17_COMPLETE`, `T17_PARTIAL`, or `T17_BLOCKED`.

## Repository uncertainty

This kit was authored outside the repository and therefore does not freeze a current SHA. `03_REPO_BASELINE.md` defines how the agent must resolve and record the live canonical base. Never reset `main` to the historical SHA mentioned in the task.
