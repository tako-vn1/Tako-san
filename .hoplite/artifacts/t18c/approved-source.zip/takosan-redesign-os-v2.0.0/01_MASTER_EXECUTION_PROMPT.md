# T17 Master Execution Prompt

You are implementing **T17 — Takosan UI V2 Full Product Redesign** in the canonical repository `frigo-6/Frigo-dev`.

This ZIP is the official design contract. Extract it outside tracked application paths first, read every required specification, then copy only intentional assets/code into the repository. Do not commit the ZIP itself unless the repository's documentation policy explicitly calls for it.

## Start safely

1. Verify repository identity, remotes, current branch, status, and remote `main`.
2. Fetch without rewriting history.
3. Record the live remote `main` SHA. The historical observed SHA was `14f06ff7f3ede72e676e2cb42b9949cca074a070`; if remote `main` moved, use the new SHA and do not move it backwards.
4. Require a clean worktree. Preserve unrelated user work; stop only if it cannot be isolated safely.
5. Run and record baseline gates.
6. Create `feat/t17-takosan-ui-v2` from the current canonical `main`. Never work directly on `main`.

## Read before editing

Read in order:

- `02_NON_NEGOTIABLE_RULES.md`
- all files under `design-system/`, `motion/`, `layout/`, `information-architecture/`, and `states/`
- `components/COMPONENT_MATRIX.md` plus component specifications as needed
- all 27 screen files
- all files under `engineering/` and `QA/`
- `assets/brand-kit/docs/AI-AGENT-RENDERING.md`
- `assets/ASSET_MANIFEST.json`

## Audit and implement

Inspect the real frontend, routes, tests, Tailwind configuration, package manifest, and design-token sources. Create `docs/ai/T17_UI_V2_AUDIT.md` using `engineering/migration-map.md` as the structure. The audit must enumerate routes, pages, duplicate primitives, hardcoded branded colors, Frigo presentation leaks, animation utilities, phone-width constraints, modal/dialog variants, Week/Planner overlap, account/settings overlap, and notification inbox/preferences overlap.

Continue immediately from audit to implementation. This is not a planning-only task.

Implement in checkpoint phases:

1. establish audit and baseline;
2. semantic design system and reusable primitives;
3. motion system and responsive AppShell;
4. entry, auth, OTP, onboarding;
5. Home, scan, inventory;
6. recipes, cooking, shopping;
7. Planner consolidation;
8. account, settings, notifications, privacy, Plus;
9. responsive and visual coverage;
10. legacy presentation cleanup;
11. certification documentation.

Use the commit sequence in `engineering/commit-checkpoints.md`. Pages should compose feature components and shared primitives, not become new monoliths.

## Absolute boundaries

Do not deploy, merge, modify production Cloudflare resources, redesign backend contracts, weaken auth, change Inventory Truth semantics, change OCR/AI routing, change recipe rollout authority, change planning algorithms, change D1 schema without an unavoidable existing-contract need, or alter PayOS/payment grants. `PayOS: zero application change.`

If the UI requests unsupported behavior, render an honest unavailable or not-configured state. Never invent persistence, data, API success, or user records.

## Verification and delivery

Run the complete repository gates and isolated T17 browser suite described in `QA/`. Test all required viewports and state classes. Record commands, counts, artifact paths, known limitations, SHAs, clean status, and preservation statements in `docs/ai/T17_UI_V2_REPORT.md`.

Push only the T17 branch. Do not merge. Do not deploy. Mark `T17_COMPLETE` only when every item in `QA/definition-of-done.md` is evidenced; otherwise report `T17_PARTIAL` or `T17_BLOCKED` with exact gaps.

Begin now. Do not ask for routine confirmation. Make conservative choices from the existing architecture and continue until complete or a genuine hard blocker is reached.
