# Repository baseline contract

Repository: `frigo-6/Frigo-dev`

Target branch: `feat/t17-takosan-ui-v2`

Historical main observation: `14f06ff7f3ede72e676e2cb42b9949cca074a070`. This is context only, not a pin.

## Required pre-edit record

Capture in `docs/ai/T17_UI_V2_AUDIT.md`:

- absolute checkout path;
- `git remote -v` identity;
- current branch and `git status --short`;
- fetched remote `main` full SHA;
- Node and pnpm versions;
- package manager lockfile state;
- baseline command results and test counts;
- pre-existing warnings or vulnerabilities;
- existing T13 Playwright configuration and inventory tests.

## Baseline commands

Use repository scripts as authoritative. At minimum execute:

```bash
pnpm install
pnpm lint
pnpm typecheck
pnpm test
pnpm check:migrations
pnpm build
```

If the repository exposes a broader `pnpm check`, run it too. Do not normalize failures away. Record a reproducible baseline before attributing later results to T17.

## Stop conditions

Stop and report only for a genuine safety blocker: wrong repository, inability to resolve canonical `main`, unrelated dirty changes that overlap required files and cannot be isolated, missing credentials needed for a mandatory non-production test, or a broken baseline that makes safe UI migration impossible. Ordinary warnings and fixable test failures are not reasons to stop.
