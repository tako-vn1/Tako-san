# AppShell V2

AppShell is the sole owner of global viewport composition, navigation placement, content gutters, safe areas, and maximum content width.

- Mobile `<640`: bottom navigation, single column, edge-to-edge page canvas, `env(safe-area-inset-*)` support.
- Tablet `640–1023`: navigation rail, flexible content, optional two-column Home/Planner layouts.
- Desktop `>=1024`: persistent or compact sidebar; content canvas normally 960–1200px; multi-column compositions where useful.

Remove repeated `max-w-md mx-auto` from migrated pages. A page may request a semantic width (`compact`, `default`, `wide`, `fullscreen`), but must not emulate a phone on desktop.

Fullscreen exceptions: scan camera, cooking mode, auth, onboarding, and route-specific immersive states. Bottom navigation is absent in these contexts.
