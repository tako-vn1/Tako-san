# Desktop layout

Targets: 1024×768 and 1440×900. Use a persistent or compact 256px sidebar at desktop, with semantic content widths between 960 and 1200px. Keep reading columns narrower inside wide canvases. Planner and Settings may use master/detail or navigation/content layouts. Do not center a 390px phone shell. Fullscreen scan/cooking remain intentional exceptions.
