# Mobile layout

Target widths: 360, 390, 430px. Use 16px inline gutters unless an immersive surface intentionally reaches the edge. Bottom navigation reserves content space plus safe area; fixed CTAs sit above it. Keep one primary action per region, 44px touch targets, readable keyboard states, and no horizontal scrolling at 200% text zoom. Sheets may approach full height but must preserve a visible dismiss path and keyboard-safe actions.
