# Safe-area and fixed UI

Apply safe-area insets to mobile navigation, immersive headers, sheets, dialogs, camera controls, and cooking controls. Reserve layout space for fixed elements; never solve overlap with arbitrary padding. Test iOS-style top/bottom insets, Android gesture navigation, virtual keyboards, landscape, zoom, and long Vietnamese labels. Toasts must avoid fixed CTAs and navigation.
