# Tablet layout

Target: 768×1024 and landscape equivalents. Use an 80px navigation rail. Home, Planner, inventory filters, and Settings may become two columns when relationships benefit. Do not merely stretch mobile cards. Dialogs and sheets must fit with 24px viewport clearance; sticky actions must avoid the rail and software keyboard.
