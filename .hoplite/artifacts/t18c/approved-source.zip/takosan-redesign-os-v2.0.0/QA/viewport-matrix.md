# Viewport certification matrix

Test at minimum:

| Viewport | Primary purpose |
| --- | --- |
| 360×800 | minimum common mobile width, long Vietnamese labels |
| 390×844 | canonical mobile screenshots |
| 430×932 | large mobile and safe-area/fixed actions |
| 768×1024 | tablet rail and two-column opportunities |
| 1024×768 | desktop breakpoint at constrained height |
| 1440×900 | full desktop sidebar/canvas |

At every applicable viewport inspect horizontal overflow, safe areas, bottom navigation/rail/sidebar, sticky/fixed actions, dialogs, sheets, virtual keyboard, zoom/long text, loading, empty, error, offline, focus, and reduced motion. Use deterministic seeded/test fixtures already sanctioned by the test environment; never production user data.
