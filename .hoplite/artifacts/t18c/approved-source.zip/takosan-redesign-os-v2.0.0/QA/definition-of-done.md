# Definition of Done

T17 may be labelled `T17_COMPLETE` only when all boxes are evidenced:

- [ ] 27 screen contracts are represented in the application.
- [ ] One semantic Takosan design system and shared primitive authority exist.
- [ ] Mobile/tablet/desktop AppShell and fullscreen exceptions work.
- [ ] Required motion and reduced-motion behaviors work.
- [ ] Settings/account information architecture is separated correctly.
- [ ] Planner is canonical and legacy Week capability remains safely reachable/redirected.
- [ ] Visible Frigo presentation leaks are removed from migrated UI.
- [ ] No fake success, fake API, fake user/household data, or local business-truth clone was introduced.
- [ ] Auth, Inventory Truth, OCR/AI, recipe authority and planning algorithms are preserved.
- [ ] PayOS/payment/payment grants have zero application change.
- [ ] Required regression commands pass.
- [ ] T17 Playwright suite passes at required viewports with reviewed screenshots.
- [ ] Accessibility checklist is certified.
- [ ] `docs/ai/T17_UI_V2_AUDIT.md` and `docs/ai/T17_UI_V2_REPORT.md` are complete.
- [ ] Worktree is clean and branch pushed.
- [ ] `main` was not modified directly or merged.
- [ ] Production was not deployed or mutated.

If any box lacks evidence, use `T17_PARTIAL` or `T17_BLOCKED` and list exact missing items.
