# Acceptance criteria

## Product architecture

- All 27 registered screens exist through real routes/states.
- Shared semantic tokens and primitives are the implementation authority.
- Pages are composition-oriented; no new 500+ line monolith.
- Planner is canonical; legacy Week is compatible without competing navigation.
- Profile, food preferences, household, planning settings, notification inbox/preferences, app settings, privacy, and Plus have clear ownership.

## Behavior preservation

- Public landing and corrected auth funnel work.
- Auth security and onboarding server truth are preserved.
- Inventory Truth and concurrency are preserved.
- OCR/AI, recipe authority and Planner algorithms are preserved.
- PayOS/payment/payment-grant application diff is zero.
- Unsupported capabilities show an honest state.

## Experience

- Mobile, tablet and desktop compositions are intentional.
- No major overflow, clipping, fixed-action collision or phone shell on desktop.
- Motion is semantic and reduced motion works.
- Loading, empty, error, offline, disabled and destructive states are represented.
- Keyboard, focus, screen-reader semantics, contrast and 44px targets pass review.

## Delivery

- Required commands genuinely pass or exact failures are reported.
- T17 visual suite is isolated from T13.
- Screenshots contain no private data.
- Branch is pushed, worktree clean, main untouched and production undeployed.
