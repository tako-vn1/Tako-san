# Accessibility checklist

- One clear page heading; sequential heading levels.
- Native links/buttons/inputs; no div-only controls.
- 44×44px minimum touch targets.
- Visible focus; logical order; no focus hidden behind fixed UI.
- `aria-current` for navigation; `aria-selected` and keyboard behavior for tabs.
- `role=switch` and `aria-checked` for switches.
- Dialog/sheet labelled, trapped, Escape-aware and focus-returning.
- Errors/status announced at appropriate live-region priority.
- Field label, description and error associations.
- Selection/status never communicated by color alone.
- Text and UI contrast meet WCAG AA.
- Content survives 200% zoom and long Vietnamese text.
- Reduced motion preserves comprehension and control.
- Images have meaningful alt or empty alt when decorative.
- OTP supports paste and does not spam countdown announcements.
- Timers announce useful milestones, not every tick.
