# T17 visual regression plan

Create isolated coverage under `tests/e2e/t17-ui/` and a separate config/project or namespace that does not weaken T13/Inventory tests.

Canonical screenshot surfaces:

`landing`, `auth`, `onboarding`, `home`, `inventory`, `scan-review`, `recipes`, `recipe-detail`, `cook`, `planner`, `shopping`, `profile`, `preferences`, `settings`, `plus`.

Capture important surfaces at 390 mobile, 768 tablet and 1440 desktop. At least one test each must cover dialog, bottom sheet, long Vietnamese text, loading, empty, error, offline, reduced motion and keyboard focus.

Stabilize time, locale, animations, network fixtures, IDs and fonts. Mask only genuinely nondeterministic/private regions; do not mask layout failures. Store screenshots and traces only in safe test artifact paths and list them in the T17 report. Never update baselines blindly after a diff.
