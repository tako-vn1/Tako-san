# Target frontend architecture

Adapt names to the repository's established conventions; do not create a parallel app tree simply to match this example.

```text
src/web/
├── app/                 # router, providers, AppShell, route guards
├── design-system/
│   ├── tokens/          # one semantic source, legacy bridges
│   ├── primitives/      # shared UI primitives
│   └── motion/          # provider and motion primitives
├── features/
│   ├── auth/
│   ├── onboarding/
│   ├── home/
│   ├── scan/
│   ├── inventory/
│   ├── recipes/
│   ├── cooking/
│   ├── shopping/
│   ├── planner/
│   ├── account/
│   ├── notifications/
│   └── plus/
├── pages/               # thin route composition
└── styles/              # globals and generated semantic variables
```

Data/API/store modules remain the source of business truth. Feature UI may adapt data for presentation but must not create a second mutable domain store. Route pages should usually compose providers, feature sections, and state boundaries; a new 500+ line page fails review.
