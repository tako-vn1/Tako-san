# Dependency policy

Use existing dependencies first. `motion/react` is the preferred motion API only when package/runtime compatibility is verified. Add the smallest supported dependency version through the repository package manager and commit lockfile changes.

Do not add another design-system framework, modal library, state manager, icon family, date library, validation library, or CSS-in-JS runtime without a documented gap the current stack cannot safely fill. Canonical Takosan icons remain authoritative. New dependencies must work in the existing Cloudflare/browser build, tree-shake appropriately, and pass audit/build/tests.
