# Audit and migration map

Before editing, inventory all real files under `src/web/`, frontend-relevant configuration, `design-tokens/`, tests, and routing. Build a table with:

| Current file/pattern | Current responsibility | Target authority | Action | Risk/tests |
| --- | --- | --- | --- | --- |

Classify each item as `retain`, `adapt`, `move`, `bridge`, `redirect`, or `retire after proof`.

Mandatory searches include:

- visible `Frigo`/`FRIGO` presentation strings;
- `frigo-*` presentation tokens/classes;
- raw brand hex values;
- `max-w-md`, `mx-auto`, fixed phone widths;
- local Button/Input/Card/Dialog/Switch implementations;
- `transition-all`, `animate-in`, `fade-in`, `slide-in-*`, arbitrary z-index;
- legacy `/week` routes and Planner routes;
- Settings/Profile/Preferences/Notifications route overlap;
- fake/demo user, household, notification, success, export/delete behavior.

Do not mechanically replace internal identifiers, migrations, API names, test fixtures, or compatibility terms merely because they contain `Frigo`. Only user-visible presentation and redundant presentation tokens are in scope.
