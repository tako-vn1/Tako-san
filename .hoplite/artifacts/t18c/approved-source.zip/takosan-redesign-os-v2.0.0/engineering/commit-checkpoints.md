# Checkpoint commits

Use meaningful, independently recoverable commits approximately in this order:

1. `chore(t17): establish ui v2 baseline`
2. `feat(ui): add semantic Takosan design system`
3. `feat(ui): add motion and responsive app shell`
4. `feat(ui): rebuild entry auth and onboarding`
5. `feat(ui): rebuild home scan and inventory`
6. `feat(ui): rebuild recipes cooking and shopping`
7. `feat(ui): consolidate planner experience`
8. `feat(ui): rebuild account settings and plus`
9. `test(ui): add responsive visual coverage`
10. `chore(ui): retire legacy presentation debt`
11. `docs(t17): certify Takosan UI V2`

Run focused tests before every checkpoint and relevant broad gates after each functional phase. Never squash unfinished work into a misleading “complete” commit. If interrupted, update the handoff before stopping.
