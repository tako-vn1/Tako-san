# Presentation debt retirement

Retire only after all consumers migrate and tests prove equivalence:

- duplicate page-local action/input/card/dialog/switch primitives;
- dead animation utilities and no-op class names;
- legacy visible Frigo assets/strings in Takosan surfaces;
- repeated page-level phone-width wrappers;
- duplicate navigation shells;
- competing Week presentation when Planner exposes all retained capabilities;
- generic preference routes superseded by dedicated screens;
- notification preference controls inside the inbox;
- demo-only fake success/data paths in production UI.

Do not delete a legacy route, adapter, or component simply because it looks old. Record consumers, replacement, redirect, regression coverage, and safe removal evidence.
