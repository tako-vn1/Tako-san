# Protected behavior and files

Discover the actual file paths during audit and record them in `T17_UI_V2_AUDIT.md`. Treat code owning these behaviors as read-only unless a minimal presentation adapter is unavoidable and fully tested:

- authentication/session/cookie/CSRF/Turnstile/Google security;
- onboarding server authority;
- Inventory Truth, reconciliation, writer fencing and optimistic concurrency;
- OCR/image processing and AI provider routing;
- recipe catalog authority and Shadow/Canary rollout;
- meal-planning, budget and shopping optimization algorithms;
- D1 schemas/migrations;
- Cloudflare deployment/runtime configuration;
- PayOS, payment verification and entitlement grants.

**PayOS: zero application change.** Certify with a path-based diff against the base SHA. If the repository's payment boundary is unclear, audit and list it before any Plus UI change.
