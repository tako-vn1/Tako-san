# Brand cleanup

User-visible product naming is Takosan. Replace visible `Frigo Plus`, `Frigo Week`, legacy Frigo logo/wordmark and hardcoded emerald presentation with Takosan assets and semantic tokens.

Do not rename database fields, APIs, environment variables, migration names, internal domain identifiers, analytics keys, package names, or compatibility routes merely for cosmetics. Email/server copy is in scope only when it is frontend-owned and changing it cannot alter backend behavior. Create a before/after string inventory and confirm user-visible leaks through screenshots and tests.
