# Empty and error states

`EmptyState` explains why the region is empty and offers at most one primary recovery/creation action. `ErrorState` states what failed, what remains safe, and whether retry is available. Use supplied mascot poses sparingly. Empty is not error; unavailable is not disabled; offline is not server failure. Preserve already-known data when a refresh fails.
