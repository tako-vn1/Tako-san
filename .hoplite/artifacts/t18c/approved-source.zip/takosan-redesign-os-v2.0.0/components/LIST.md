# Lists and rows

`List` establishes density and separators. `ListRow` supports identity, primary text, metadata, status, and limited actions. `SettingsRow` is only for preference/navigation settings—not inventory, shopping, notifications, or household members. Rows use correct link/button semantics and remain readable with long Vietnamese copy.
