# Actions

Implement `Button`, `IconButton`, `FAB`, and `LinkButton` from one action foundation. Variants: primary, secondary, quiet, danger; sizes: compact, default, large. Preserve dimensions while loading. Icon-only actions require an accessible name and 44px target. Use anchors for navigation and buttons for actions. `FAB` is reserved for the screen's primary creation action; no more than one visible FAB.
