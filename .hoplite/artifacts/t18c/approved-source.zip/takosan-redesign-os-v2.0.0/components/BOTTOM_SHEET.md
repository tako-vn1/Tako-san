# BottomSheet

BottomSheet is the mobile-first transient detail/action surface used for filters, Planner swap, and compact editors where appropriate. It requires labelled content, focus management, safe-area padding, keyboard-safe actions, scroll containment, visible close, and backdrop dismissal only when lossless. Tablet/desktop may render the same contract as a dialog or side panel without duplicating business state.
