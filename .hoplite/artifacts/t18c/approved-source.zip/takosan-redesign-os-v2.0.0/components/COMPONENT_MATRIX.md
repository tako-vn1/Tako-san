# Component matrix

| Family | Components | Required semantics |
| --- | --- | --- |
| Actions | Button, IconButton, FAB, LinkButton | native button/link, loading, disabled, focus-visible |
| Surfaces | Card, Surface, Section, Divider | restrained borders/elevation, semantic nesting |
| Selection | Badge, StatusBadge, Chip, FilterChip, Tag, SegmentedControl, Tabs | selected state, keyboard support, no color-only status |
| Forms | TextField, SearchField, NumberField, SelectField, Textarea, Switch, Checkbox, Radio, RadioCard, ChoiceCard | labels, descriptions, errors, touch targets |
| Identity | Avatar, Thumbnail | fallback, alt contract, privacy-safe |
| Page | Page, PageHeader, SectionHeader | shell-owned width, heading hierarchy |
| Overlays | BottomSheet, Dialog, AlertDialog, Toast | focus trap/return, Escape, modal ownership |
| Feedback | Progress, Spinner, Skeleton, EmptyState, ErrorState | announcements, reduced motion |
| Lists | List, ListRow, SettingsRow | correct interactive element, stable density |
| Fixed actions | BottomCTA, StickyActions | safe area, keyboard, nav avoidance |

Each component has one implementation authority. Variants live with the primitive. Feature components may compose primitives but must not clone their styling or semantics.
