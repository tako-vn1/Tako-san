# Chips, badges, and selection

`Badge` is neutral metadata; `StatusBadge` maps semantic states; `Tag` labels content; `Chip` is compact content or toggle; `FilterChip` represents filter state; `SegmentedControl` switches a small set of peer views; `Tabs` changes panels. Use `aria-selected`/tab roles where appropriate. Selected state uses icon/weight/shape plus color. Chips are not substitutes for checkboxes when form submission semantics matter.
