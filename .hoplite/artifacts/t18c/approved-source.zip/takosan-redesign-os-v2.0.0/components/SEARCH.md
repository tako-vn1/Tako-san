# SearchField

Use a real search input with accessible label, clear action, optional submit action, and debounced behavior only when consistent with existing data contracts. Preserve query across route/back navigation where the current product does so. Search must not silently become a client-only shadow of server filters.
