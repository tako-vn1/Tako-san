# Page composition

`Page` requests semantic width and owns vertical rhythm, not global viewport layout. `PageHeader` supplies heading, optional back/breadcrumb, and restrained actions. `SectionHeader` links title, summary, and one action. Heading order is sequential. Pages should mostly compose feature components and state boundaries.
