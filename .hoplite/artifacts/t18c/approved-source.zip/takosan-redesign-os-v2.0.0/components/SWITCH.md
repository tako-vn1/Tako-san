# Binary and choice controls

`Switch` is for immediate on/off settings and exposes `role=switch` with `aria-checked`. Use `Checkbox` for multi-select or form submission, `Radio` for one choice, `RadioCard`/`ChoiceCard` for high-emphasis onboarding choices. Disabled/unavailable states must explain why. Never show a working switch for unsupported notification infrastructure.
