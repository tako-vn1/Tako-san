# Dialogs

`Dialog` owns focus trap, initial focus, Escape, backdrop, scroll lock, labelled title/description, and focus return. `AlertDialog` is reserved for irreversible or high-risk confirmation and requires explicit cancel/default-safe focus. Use `AnimatedDialog` without weakening semantics. Do not stack dialogs; close or replace the current owner.
