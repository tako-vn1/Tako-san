# BottomCTA and StickyActions

Use `BottomCTA` for one mobile primary action and `StickyActions` for paired editor actions. They reserve layout space, respect safe areas, avoid bottom navigation, remain visible above the keyboard when appropriate, and never conceal validation errors. Desktop may render equivalent actions inline or in a sticky panel.
