# Toast

Toasts confirm non-critical completed actions or announce transient failures. They never replace persistent error content, destructive confirmation, or unsupported-state messaging. Use an ARIA live region, deduplicate repeated messages, stack without covering fixed UI, and provide an undo action only when rollback is real.
