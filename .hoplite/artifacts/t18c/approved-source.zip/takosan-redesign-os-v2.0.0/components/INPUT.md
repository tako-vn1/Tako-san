# Inputs

All fields share label, optional description, required marker, error text, disabled/read-only state, focus styling, and stable height. `NumberField` has typed input plus accessible increment/decrement controls. `SelectField` must work with keyboard and long Vietnamese options. `Textarea` reports limits when present. Never hide server errors in a toast when they belong to a field.
