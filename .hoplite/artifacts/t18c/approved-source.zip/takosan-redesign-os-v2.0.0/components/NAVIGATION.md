# Navigation

One navigation model renders as mobile bottom bar, tablet rail, and desktop sidebar. It uses real links, current-route semantics, stable labels/icons, safe areas, and `SharedIndicator`. Primary destinations: Home, Fridge, Recipes, Planner, Profile. Scan may be a prominent contextual action. Hide navigation in auth, onboarding, scan camera, and cooking mode.
