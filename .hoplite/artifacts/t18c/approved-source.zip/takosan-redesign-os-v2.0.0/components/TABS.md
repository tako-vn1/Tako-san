# Tabs and segmented controls

Tabs require `role=tablist`, roving keyboard focus, `aria-selected`, controlled panels, and stable deep-link behavior when routes currently support it. `SegmentedControl` is for 2–4 compact peer choices. Use `SharedIndicator`; reduced motion makes the indicator change instant.
