# Progress and loading

`Progress` exposes determinate value when known; otherwise use a labelled indeterminate state. `Spinner` is for compact waits, `Skeleton` for stable content geometry. Avoid full-screen spinners when existing content can remain. Loading regions announce status without repeatedly interrupting screen readers. Reduced motion disables shimmer.
