# Surfaces

`Surface` provides tone/elevation. `Card` is a composed content container, not the default wrapper for every section. `Section` handles spacing and optional heading; `Divider` separates dense rows. Prefer whitespace and background tone to boxes. Nested cards are normally rejected. Clickable cards use one semantic interactive target and must not contain competing nested actions unless explicitly designed.
