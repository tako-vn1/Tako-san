# Non-negotiable rules

1. Existing security and business truth beat screenshots.
2. Inventory Truth is immutable: `UNKNOWN`, `ESTIMATED`, and `KNOWN` expiry are different facts and must remain visible and distinct.
3. Preserve inventory writer, reconciliation, fencing, optimistic concurrency, and server authority.
4. Preserve auth/session/cookie/CSRF/Turnstile/Google GSI behavior and T16 funnel corrections.
5. Preserve OCR processing, image privacy, AI routing, recipe authority, Shadow/Canary rollout, planning algorithms, budget logic, and shopping optimization.
6. **PayOS and payment grants receive zero application change.** UI presentation may be rebranded without changing payment behavior.
7. Do not modify production, deploy, merge to `main`, or reset `main` backwards.
8. Semantic tokens beat local styling. Shared primitives beat page-local duplicates.
9. Responsive composition beats phone-width emulation. AppShell owns global width.
10. Honest unavailable state beats fake feature. Never fake success, API data, persistence, a household member, export, account deletion, notification delivery, or entitlement.
11. Takosan is the visible brand. Internal Frigo/domain compatibility identifiers may remain when cosmetic renaming would risk behavior.
12. Supplied SVGs and mascot assets are canonical. Never crop boards or redraw brand marks.
13. Motion must communicate state, direction, continuity, or feedback; decorative motion is rejected.
14. Reduced motion is mandatory.
15. Accessibility is a release gate, not a later enhancement.
16. Legacy deep links may redirect, but domain capabilities must not disappear before an equivalent route exists.
17. Do not create a second Planner, settings system, modal framework, button family, token source, or business-state store.
18. Do not claim a test, viewport, or screen passed unless it was actually executed and evidenced.
19. If requirements conflict, apply the priority order in `00_README_FIRST.md` and document the decision.
20. If incomplete, say so precisely. `T17_COMPLETE` is not a narrative preference; it is a certified status.
