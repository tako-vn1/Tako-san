# Disabled and unavailable

Disabled means a currently valid control cannot be used due to state. Unavailable means the product capability is not configured or implemented. Explain unavailable notification channels, household actions, export/delete, or sharing features. Avoid dead controls; prefer informative static rows with a clear status.
