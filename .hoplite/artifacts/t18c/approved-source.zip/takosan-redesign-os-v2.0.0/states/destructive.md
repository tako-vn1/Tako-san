# Destructive actions

Use danger color and `AlertDialog` only for genuinely destructive operations. Name the affected entity and consequence, use a safe default focus, prevent duplicate submission, and display server result truthfully. Account deletion must not exist as a fake success flow when no API supports it.
