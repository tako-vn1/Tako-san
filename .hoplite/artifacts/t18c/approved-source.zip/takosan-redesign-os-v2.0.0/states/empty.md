# Empty

State what is empty, why it matters, and the single best next action. Use the correct domain action: add or scan an ingredient, create a plan, discover recipes, or configure a real capability. Do not populate fake sample users, meals, ingredients, notifications, or purchases.
