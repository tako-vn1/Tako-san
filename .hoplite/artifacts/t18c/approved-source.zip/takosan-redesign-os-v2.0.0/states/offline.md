# Offline

Use existing offline/PWA capability only. Mark cached or stale content honestly, queue writes only if the current architecture already guarantees safe replay, and disable network-only actions with explanation. Do not claim a save completed while offline unless the application has durable synchronization semantics.
