# Error

Keep trustworthy content visible, explain the affected scope, offer retry when safe, and preserve user input. Field errors stay with fields; region errors stay with regions. Auth/security errors retain current semantics. Never convert a failure into a success toast or silently fall back to fabricated data.
