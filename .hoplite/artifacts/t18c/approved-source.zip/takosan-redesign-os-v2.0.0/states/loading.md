# Loading

Preserve layout with skeletons for first load and retain real content during background refresh. Use spinners only inside compact controls or unknown geometry. Announce a meaningful status. Do not re-run section entrance animations on refresh or show invented placeholder facts.
