# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: t17-ui.e2e.ts >> content survives 200% text zoom without horizontal scrolling
- Location: tests/e2e/t17-ui/t17-ui.e2e.ts:149:1

# Error details

```
Error: / must not scroll horizontally at 200% text zoom

expect(received).toBeLessThanOrEqual(expected)

Expected: <= 1
Received:    46
```

# Page snapshot

```yaml
- generic [ref=f4e3]:
  - navigation "Điều hướng chính" [ref=f4e4]:
    - link "Takosan — Trang chủ" [ref=f4e5] [cursor=pointer]:
      - /url: /
      - img "Takosan" [ref=f4e6]
    - list [ref=f4e7]:
      - listitem [ref=f4e8]:
        - link "Trang chủ" [ref=f4e9] [cursor=pointer]:
          - /url: /
      - listitem [ref=f4e13]:
        - link "Tủ lạnh" [ref=f4e14] [cursor=pointer]:
          - /url: /fridge
      - listitem [ref=f4e18]:
        - link "Công thức" [ref=f4e19] [cursor=pointer]:
          - /url: /recipes
      - listitem [ref=f4e23]:
        - link "Thực đơn" [ref=f4e24] [cursor=pointer]:
          - /url: /planner
      - listitem [ref=f4e28]:
        - link "Tôi" [ref=f4e29] [cursor=pointer]:
          - /url: /me
    - link "Quét nguyên liệu" [ref=f4e33] [cursor=pointer]:
      - /url: /scan
  - main [ref=f4e37]:
    - generic [ref=f4e38]:
      - generic [ref=f4e39]:
        - generic [ref=f4e40]:
          - button "Trang cá nhân" [ref=f4e41] [cursor=pointer]
          - generic [ref=f4e42]:
            - heading "Xin chào, Preview! 👋" [level=1] [ref=f4e43]
            - paragraph [ref=f4e44]: Hôm nay ăn gì đây?
        - button "Thông báo" [ref=f4e45] [cursor=pointer]
      - generic [ref=f4e49]:
        - generic [ref=f4e50]:
          - generic [ref=f4e53]:
            - generic [ref=f4e54]: Hôm nay
            - heading "Chưa có thực đơn tuần này" [level=2] [ref=f4e57]
            - paragraph [ref=f4e58]: Lên thực đơn để Takosan gợi ý món từ nguyên liệu sẵn có.
            - button "Lên thực đơn tuần" [ref=f4e59] [cursor=pointer]
          - generic [ref=f4e66]:
            - generic [ref=f4e67]:
              - heading "NÊN DÙNG SỚM" [level=2] [ref=f4e68]
              - button "Xem tất cả (5)" [ref=f4e69] [cursor=pointer]
            - button "Rau muống Rau muống Chưa rõ hạn dùng" [ref=f4e73] [cursor=pointer]:
              - img "Rau muống" [ref=f4e75]
              - paragraph [ref=f4e76]: Rau muống
              - generic [ref=f4e77]: Chưa rõ hạn dùng
        - generic [ref=f4e78]:
          - generic [ref=f4e79]:
            - heading "Gợi ý cho bạn" [level=2] [ref=f4e80]
            - button "Không mua thêm gì" [ref=f4e81] [cursor=pointer]
          - group "Lọc theo ẩm thực" [ref=f4e86]:
            - button "Tất cả" [pressed] [ref=f4e87] [cursor=pointer]
            - button "🇻🇳 Món Việt" [ref=f4e88] [cursor=pointer]
            - button "🇰🇷 Món Hàn" [ref=f4e89] [cursor=pointer]
            - button "🇯🇵 Món Nhật" [ref=f4e90] [cursor=pointer]
            - button "🇨🇳 Trung Hoa" [ref=f4e91] [cursor=pointer]
            - button "🇹🇭 Món Thái" [ref=f4e92] [cursor=pointer]
            - button "🇮🇹 Món Ý" [ref=f4e93] [cursor=pointer]
          - generic [ref=f4e94]:
            - link "Rau muống xào tỏi xanh giòn" [ref=f4e95] [cursor=pointer]:
              - /url: /recipes/rau-muong-xao-toi
              - generic [ref=f4e96]:
                - img "Rau muống xào tỏi xanh giòn" [ref=f4e97]
                - generic [ref=f4e98]: 🇻🇳
              - generic:
                - generic:
                  - generic [ref=f4e99]: Thiếu 3 món
                  - generic [ref=f4e100]: Khớp 25%
                - heading "Rau muống xào tỏi xanh giòn" [level=3]
                - paragraph: Rau muống ngọn non xanh mướt giòn sần sật dậy mùi thơm lừng của tỏi ta phi vàng xém cạnh, linh hồn bữa cơm gia đình.
                - generic:
                  - generic [ref=f4e103]: 10 phút
                  - generic [ref=f4e108]: 120 kcal
                  - generic [ref=f4e109]: 3 người
            - link "Canh cải xanh gừng đậu phụ thanh mát" [ref=f4e115] [cursor=pointer]:
              - /url: /recipes/canh-cai-nau-dau-phu-non
              - generic [ref=f4e116]:
                - img "Canh cải xanh gừng đậu phụ thanh mát" [ref=f4e117]
                - generic [ref=f4e118]: 🇻🇳
              - generic:
                - generic:
                  - generic [ref=f4e119]: Thiếu 3 món
                  - generic [ref=f4e120]: Khớp 25%
                - heading "Canh cải xanh gừng đậu phụ thanh mát" [level=3]
                - paragraph: Bát canh cải bẹ xanh tươi non nấu cùng gừng tươi đập dập cay nồng và đậu phụ béo mềm, xua tan hàn khí ấm bụng.
                - generic:
                  - generic [ref=f4e123]: 12 phút
                  - generic [ref=f4e128]: 125 kcal
                  - generic [ref=f4e129]: 4 người
            - link "Súp gà ngô non nấm hương trứng hoa" [ref=f4e135] [cursor=pointer]:
              - /url: /recipes/sup-ga-ngo-non-nam-huong
              - generic [ref=f4e136]:
                - img "Súp gà ngô non nấm hương trứng hoa" [ref=f4e137]
                - generic [ref=f4e138]: 🇻🇳
              - generic:
                - generic:
                  - generic [ref=f4e139]: Thiếu 3 món
                  - generic [ref=f4e140]: Khớp 40%
                - heading "Súp gà ngô non nấm hương trứng hoa" [level=3]
                - paragraph: Bát súp nóng hổi sánh óng ánh với những vân trứng hoa bay lượn, thịt gà xé ngọt mềm cùng hạt ngô ngọt giòn bùi.
                - generic:
                  - generic [ref=f4e143]: 18 phút
                  - generic [ref=f4e148]: 210 kcal
                  - generic [ref=f4e149]: 4 người
            - link "Lẩu riêu cua đồng sườn sụn bắp bò" [ref=f4e155] [cursor=pointer]:
              - /url: /recipes/lau-rieu-cua-dong-bap-bo-suon-sun
              - generic [ref=f4e156]:
                - img "Lẩu riêu cua đồng sườn sụn bắp bò" [ref=f4e157]
                - generic [ref=f4e158]: 🇻🇳
              - generic:
                - generic:
                  - generic [ref=f4e159]: Thiếu 6 món
                  - generic [ref=f4e160]: Khớp 14%
                - heading "Lẩu riêu cua đồng sườn sụn bắp bò" [level=3]
                - paragraph: Nồi lẩu riêu cua bốc khói nghi ngút thơm nồng giấm bỗng, tảng riêu cua vàng ngậy nhúng bắp bò hoa giòn và sườn non sần sật.
                - generic:
                  - generic [ref=f4e163]: 45 phút
                  - generic [ref=f4e168]: 560 kcal
                  - generic [ref=f4e169]: 6 người
            - link "Trứng hấp Chawanmushi Nhật Bản" [ref=f4e175] [cursor=pointer]:
              - /url: /recipes/chawanmushi
              - generic [ref=f4e176]:
                - img "Trứng hấp Chawanmushi Nhật Bản" [ref=f4e177]
                - generic [ref=f4e178]: 🇯🇵
              - generic:
                - generic:
                  - generic [ref=f4e179]: Thiếu 2 món
                  - generic [ref=f4e180]: Khớp 33%
                - heading "Trứng hấp Chawanmushi Nhật Bản" [level=3]
                - paragraph: Trứng hấp mịn màng như thạch tan trong miệng cùng tôm ngọt và nấm.
                - generic:
                  - generic [ref=f4e183]: 15 phút
                  - generic [ref=f4e188]: 140 kcal
                  - generic [ref=f4e189]: 2 người
```

# Test source

```ts
  66  | 
  67  |   await page.goto('/settings/notifications');
  68  |   await expect(page.getByRole('switch').first()).toBeVisible();
  69  | 
  70  |   await page.goto('/notifications');
  71  |   await expect(page.getByRole('switch').first()).toBeHidden();
  72  |   await expect(page.getByRole('link', { name: /Tùy chỉnh nhắc nhở/ })).toBeVisible();
  73  | });
  74  | 
  75  | test('honest unavailable states replace fabricated flows', async ({ page }) => {
  76  |   await page.goto('/me/household');
  77  |   await expect(page.getByText('Mời thành viên — chưa hỗ trợ')).toBeVisible();
  78  |   await expect(page.getByText('FRG-')).toBeHidden();
  79  | 
  80  |   await page.goto('/settings/privacy');
  81  |   await expect(page.getByText('Xuất dữ liệu — chưa hỗ trợ')).toBeVisible();
  82  |   await expect(page.getByText('Xóa tài khoản — chưa hỗ trợ')).toBeVisible();
  83  | });
  84  | 
  85  | test('week compatibility redirects preserve params when planner is canonical', async ({ page }) => {
  86  |   await page.goto('/week');
  87  |   await expect(page).toHaveURL(/\/planner$/);
  88  |   await page.goto('/week/plan-1/meal/meal-1');
  89  |   await expect(page).toHaveURL(/\/planner\/plan-1\/meal\/meal-1$/);
  90  |   await page.goto('/week/plan-1/shopping');
  91  |   await expect(page).toHaveURL(/\/planner\/plan-1\/shopping$/);
  92  | });
  93  | 
  94  | test('food preferences editor round-trips the real preferences contract', async ({ page }) => {
  95  |   await page.goto('/me/preferences');
  96  |   await expect(page.getByRole('heading', { name: 'Sở thích & hạn chế' })).toBeVisible();
  97  |   const vi = page.getByRole('button', { name: 'Việt Nam', exact: true });
  98  |   await expect(vi).toHaveAttribute('aria-pressed', /true|false/);
  99  |   await page.getByRole('button', { name: 'Lưu sở thích' }).click();
  100 |   await expect(page.getByText('Đã lưu sở thích.')).toBeVisible();
  101 | });
  102 | 
  103 | test('planning settings save via the week preferences contract without generating a plan', async ({ page }) => {
  104 |   await page.goto('/settings/planning');
  105 |   await expect(page.getByRole('heading', { name: 'Cài đặt lập thực đơn' })).toBeVisible();
  106 |   await expect(page.getByText(/không tạo thực đơn mới/i)).toBeVisible();
  107 |   await page.getByRole('button', { name: 'Lưu cài đặt' }).click();
  108 |   await expect(page.getByText('Đã lưu cài đặt lập thực đơn.')).toBeVisible();
  109 |   await expect(page).toHaveURL(/\/settings\/planning$/);
  110 | });
  111 | 
  112 | test('public landing renders without auth and offers the guest contract', async ({ page }, info) => {
  113 |   await page.context().clearCookies();
  114 |   await page.evaluate(() => localStorage.clear());
  115 |   await page.goto('/landing');
  116 |   await expect(page.getByRole('heading', { level: 1 }).first()).toBeVisible();
  117 |   await layout(page);
  118 |   await page.screenshot({ path: info.outputPath('landing.png') });
  119 | });
  120 | 
  121 | test('auth surface renders the split login/register shell', async ({ page }, info) => {
  122 |   await page.context().clearCookies();
  123 |   await page.evaluate(() => localStorage.clear());
  124 |   await page.goto('/auth');
  125 |   await expect(page.getByRole('heading', { name: 'Đăng nhập vào Takosan' })).toBeVisible();
  126 |   await layout(page);
  127 |   await page.screenshot({ path: info.outputPath('auth.png') });
  128 | });
  129 | 
  130 | test('reduced motion keeps planner content fully usable', async ({ page }) => {
  131 |   await page.emulateMedia({ reducedMotion: 'reduce' });
  132 |   await page.goto('/planner');
  133 |   await expectMainNav(page);
  134 |   await layout(page);
  135 | });
  136 | 
  137 | test('keyboard focus reaches primary navigation with visible focus state', async ({ page }) => {
  138 |   await completeOnboarding(page);
  139 |   await page.goto('/');
  140 |   await expectMainNav(page);
  141 |   await page.keyboard.press('Tab');
  142 |   const focused = page.evaluate(() => ({
  143 |     tag: document.activeElement?.tagName,
  144 |     href: (document.activeElement as HTMLAnchorElement | null)?.getAttribute('href'),
  145 |   }));
  146 |   expect(['A', 'BUTTON']).toContain((await focused).tag);
  147 | });
  148 | 
  149 | test('content survives 200% text zoom without horizontal scrolling', async ({ page }) => {
  150 |   await completeOnboarding(page);
  151 |   for (const path of ['/', '/fridge', '/recipes', '/shopping', '/me']) {
  152 |     await page.goto(path);
  153 |     await expectMainNav(page);
  154 |     // Let fonts/content settle before measuring a zoomed layout. Avoid
  155 |     // `networkidle` (stalls behind background polling); fonts + a frame suffice.
  156 |     await page.evaluate(() => document.fonts.ready.then(() => new Promise((r) => requestAnimationFrame(() => setTimeout(r, 200)))));
  157 |     const overflow = await page.evaluate(() => {
  158 |       document.documentElement.style.fontSize = '200%';
  159 |       // Measure after a reflow frame so transient entrance layout is done.
  160 |       return new Promise((resolve) =>
  161 |         requestAnimationFrame(() =>
  162 |           resolve(document.documentElement.scrollWidth - window.innerWidth)
  163 |         )
  164 |       );
  165 |     });
> 166 |     expect(overflow, `${path} must not scroll horizontally at 200% text zoom`).toBeLessThanOrEqual(1);
      |                                                                                ^ Error: / must not scroll horizontally at 200% text zoom
  167 |     await page.evaluate(() => { document.documentElement.style.fontSize = ''; });
  168 |   }
  169 | });
  170 | 
  171 | test('inventory bottom sheet opens labelled, closable and in-viewport', async ({ page }) => {
  172 |   await completeOnboarding(page);
  173 |   await page.goto('/fridge');
  174 |   await page.getByRole('button', { name: 'Thêm nguyên liệu' }).click();
  175 |   await expect(page.getByRole('heading', { name: 'Thêm nguyên liệu vào tủ' })).toBeVisible();
  176 |   const close = page.getByRole('button', { name: 'Đóng' });
  177 |   await expect(close).toBeVisible();
  178 |   await close.click();
  179 |   await expect(page.getByRole('heading', { name: 'Thêm nguyên liệu vào tủ' })).toBeHidden();
  180 |   await layout(page);
  181 | });
  182 | 
  183 | test('offline banner states reality and recovers when back online', async ({ page }) => {
  184 |   await completeOnboarding(page);
  185 |   await page.goto('/');
  186 |   await expectMainNav(page);
  187 |   // The banner follows the browser's offline/online events (navigator.onLine);
  188 |   // Playwright's setOffline only fails requests, so emulate the real event.
  189 |   await page.evaluate(() => window.dispatchEvent(new Event('offline')));
  190 |   await expect(page.getByText(/chế độ Ngoại tuyến/i)).toBeVisible();
  191 |   // Content remains usable while offline; the banner is honest about sync.
  192 |   await expect(page.getByRole('navigation', { name: 'Điều hướng chính' })).toBeVisible();
  193 |   await page.evaluate(() => window.dispatchEvent(new Event('online')));
  194 |   await expect(page.getByText(/chế độ Ngoại tuyến/i)).toBeHidden();
  195 | });
  196 | 
```